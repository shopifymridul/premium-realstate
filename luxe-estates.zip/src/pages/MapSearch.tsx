import { motion } from 'motion/react';
import { properties } from '@/data/mockData';
import { PropertyCard } from '@/components/ui/PropertyCard';
import { MapPin } from 'lucide-react';

export function MapSearch() {
  return (
    <div className="pt-32 pb-24 px-6 md:px-12 max-w-7xl mx-auto min-h-screen">
      <div className="flex flex-col md:flex-row justify-between items-end mb-12 gap-8">
        <div>
          <motion.span
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-gold-400 font-medium tracking-[0.2em] uppercase text-sm mb-4 block"
          >
            Explore Globally
          </motion.span>
          <motion.h1
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="text-4xl md:text-6xl font-serif text-luxe-black leading-tight"
          >
            Map <span className="italic font-light">Search</span>
          </motion.h1>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 h-[700px]">
        {/* Map Placeholder */}
        <motion.div 
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.2 }}
          className="lg:col-span-2 bg-gray-100 relative overflow-hidden border border-gray-200"
        >
          <iframe 
            src="https://www.google.com/maps/embed?pb=!1m14!1m12!1m3!1d13251.27834515591!2d-118.4003563!3d34.0736204!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!5e0!3m2!1sen!2sus!4v1697000000000!5m2!1sen!2sus" 
            width="100%" 
            height="100%" 
            style={{ border: 0, filter: 'grayscale(100%) contrast(1.2) opacity(0.8)' }} 
            allowFullScreen 
            loading="lazy" 
            referrerPolicy="no-referrer-when-downgrade"
            title="Interactive Property Map"
          ></iframe>
          
          {/* Overlay markers for visual effect */}
          <div className="absolute top-1/4 left-1/4 transform -translate-x-1/2 -translate-y-1/2">
            <div className="bg-luxe-black text-white px-3 py-1 text-sm font-medium shadow-lg flex items-center gap-2">
              <MapPin className="w-3 h-3 text-gold-400" /> $45M
            </div>
            <div className="w-0 h-0 border-l-[6px] border-r-[6px] border-t-[8px] border-l-transparent border-r-transparent border-t-luxe-black mx-auto"></div>
          </div>
          
          <div className="absolute top-1/2 left-2/3 transform -translate-x-1/2 -translate-y-1/2">
            <div className="bg-luxe-black text-white px-3 py-1 text-sm font-medium shadow-lg flex items-center gap-2">
              <MapPin className="w-3 h-3 text-gold-400" /> $65M
            </div>
            <div className="w-0 h-0 border-l-[6px] border-r-[6px] border-t-[8px] border-l-transparent border-r-transparent border-t-luxe-black mx-auto"></div>
          </div>
        </motion.div>

        {/* Property List Sidebar */}
        <motion.div 
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.3 }}
          className="overflow-y-auto pr-4 space-y-6 no-scrollbar"
        >
          <div className="sticky top-0 bg-white/90 backdrop-blur-md pb-4 z-10">
            <h3 className="text-lg font-serif text-luxe-black">Properties in View ({properties.slice(0, 4).length})</h3>
          </div>
          {properties.slice(0, 4).map((property, index) => (
            <PropertyCard key={property.id} property={property} index={index} />
          ))}
        </motion.div>
      </div>
    </div>
  );
}
