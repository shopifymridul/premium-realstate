import { motion } from 'motion/react';
import { Link } from 'react-router-dom';
import { ArrowRight } from 'lucide-react';
import { articles } from '@/data/mockArticles';

export function Journal() {
  return (
    <div className="pt-32 pb-24 px-6 md:px-12 max-w-7xl mx-auto min-h-screen">
      <motion.span
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-gold-400 font-medium tracking-[0.2em] uppercase text-sm mb-4 block"
      >
        Insights & Lifestyle
      </motion.span>
      <motion.h1
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1 }}
        className="text-4xl md:text-6xl font-serif text-luxe-black leading-tight mb-16"
      >
        The <span className="italic font-light">Journal</span>
      </motion.h1>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-12">
        {articles.map((article, index) => (
          <motion.article
            key={article.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 + (index % 3) * 0.1 }}
            className="group cursor-pointer flex flex-col h-full"
          >
            <Link to={`/blog/${article.id}`} className="relative h-64 mb-6 overflow-hidden shrink-0 block">
              <img 
                src={article.image} 
                alt={article.title} 
                className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
              />
            </Link>
            <div className="flex items-center justify-between text-xs uppercase tracking-wider text-gray-400 mb-3 shrink-0">
              <span>{article.category}</span>
              <span>{article.date}</span>
            </div>
            <h3 className="text-2xl font-serif text-luxe-black mb-3 group-hover:text-gold-400 transition-colors line-clamp-2 shrink-0">
              {article.title}
            </h3>
            <p className="text-gray-600 font-light leading-relaxed mb-6 line-clamp-3 flex-grow">
              {article.excerpt}
            </p>
            <Link to={`/blog/${article.id}`} className="inline-flex items-center text-sm uppercase tracking-wider font-medium text-luxe-black group-hover:text-gold-400 transition-colors shrink-0 mt-auto">
              Read Article <ArrowRight className="ml-2 w-4 h-4" />
            </Link>
          </motion.article>
        ))}
      </div>
    </div>
  );
}
