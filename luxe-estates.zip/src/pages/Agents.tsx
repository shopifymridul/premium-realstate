import { motion } from 'motion/react';
import { agents } from '@/data/mockData';
import { Mail, Phone, Instagram, Linkedin } from 'lucide-react';
import { Link } from 'react-router-dom';

export function Agents() {
  return (
    <div className="pt-32 pb-24 px-6 md:px-12 max-w-7xl mx-auto min-h-screen">
      <div className="mb-16">
        <motion.span
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-gold-400 font-medium tracking-[0.2em] uppercase text-sm mb-4 block"
        >
          Our Team
        </motion.span>
        <motion.h1
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="text-4xl md:text-6xl font-serif text-luxe-black leading-tight"
        >
          Real Estate <span className="italic font-light">Advisors</span>
        </motion.h1>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-12">
        {agents.map((agent, index) => (
          <motion.div
            key={agent.id}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: index * 0.1 }}
            className="group"
          >
            <Link to={`/agents/${agent.id}`} className="block relative aspect-[3/4] overflow-hidden mb-6">
              <img
                src={agent.image}
                alt={agent.name}
                className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                loading="lazy"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-black/20 opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
            </Link>
            <div className="text-center">
              <Link to={`/agents/${agent.id}`}>
                <h3 className="text-2xl font-serif text-luxe-black mb-1 hover:text-gold-400 transition-colors">{agent.name}</h3>
              </Link>
              <p className="text-gold-400 text-sm tracking-wider uppercase mb-4">{agent.role}</p>
              <div className="flex justify-center gap-4 text-gray-500">
                <a href={`tel:${agent.phone}`} className="hover:text-gold-400 transition-colors">
                  <Phone className="w-4 h-4" />
                </a>
                <a href={`mailto:${agent.email}`} className="hover:text-gold-400 transition-colors">
                  <Mail className="w-4 h-4" />
                </a>
                <a href="#" className="hover:text-gold-400 transition-colors">
                  <Instagram className="w-4 h-4" />
                </a>
                <a href="#" className="hover:text-gold-400 transition-colors">
                  <Linkedin className="w-4 h-4" />
                </a>
              </div>
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  );
}
