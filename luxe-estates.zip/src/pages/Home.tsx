import { Hero, AdvancedSearch } from '@/components/home/Hero';
import { FeaturedProperties, Categories } from '@/components/home/Featured';
import { WhyChooseUs, Stats } from '@/components/home/About';
import { Agents, Testimonials } from '@/components/home/People';
import { ContactPreview, MapPreview } from '@/components/home/Contact';

export function Home() {
  return (
    <div className="bg-white">
      <Hero />
      <AdvancedSearch />
      <FeaturedProperties />
      <Categories />
      <WhyChooseUs />
      <Stats />
      
      {/* Marquee Section */}
      <section className="py-12 bg-luxe-black border-y border-gray-800 overflow-hidden">
        <div className="flex whitespace-nowrap animate-marquee">
          {[...Array(2)].map((_, i) => (
            <div key={i} className="flex items-center gap-16 px-8 text-gold-400/50 font-serif text-2xl uppercase tracking-[0.2em]">
              <span>Forbes Global Properties</span>
              <span>•</span>
              <span>Christie's International Real Estate</span>
              <span>•</span>
              <span>Sotheby's International Realty</span>
              <span>•</span>
              <span>Knight Frank</span>
              <span>•</span>
            </div>
          ))}
        </div>
      </section>

      <MapPreview />
      <Agents />
      <Testimonials />
      <ContactPreview />
    </div>
  );
}
