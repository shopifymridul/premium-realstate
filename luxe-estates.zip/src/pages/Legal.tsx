import { motion } from 'motion/react';

export function Privacy() {
  return (
    <div className="pt-32 pb-24 px-6 md:px-12 max-w-4xl mx-auto min-h-screen">
      <motion.span
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-gold-400 font-medium tracking-[0.2em] uppercase text-sm mb-4 block"
      >
        Legal Information
      </motion.span>
      <motion.h1
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1 }}
        className="text-4xl md:text-6xl font-serif text-luxe-black leading-tight mb-16"
      >
        Privacy <span className="italic font-light">Policy</span>
      </motion.h1>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
        className="prose prose-lg text-gray-600 font-light leading-relaxed max-w-none"
      >
        <p>Last updated: October 2023</p>
        
        <h2 className="text-2xl font-serif text-luxe-black mt-12 mb-6">1. Information We Collect</h2>
        <p>We collect information that you provide directly to us, such as when you create an account, subscribe to our newsletter, request property information, or communicate with our agents. This may include your name, email address, phone number, and preferences.</p>
        
        <h2 className="text-2xl font-serif text-luxe-black mt-12 mb-6">2. How We Use Your Information</h2>
        <p>We use the information we collect to provide, maintain, and improve our services, communicate with you about properties that match your criteria, process transactions, and send you marketing communications (which you can opt out of at any time).</p>
        
        <h2 className="text-2xl font-serif text-luxe-black mt-12 mb-6">3. Information Sharing</h2>
        <p>We do not sell your personal information. We may share your information with third-party service providers who perform services on our behalf, such as hosting, marketing, and analytics, under strict confidentiality agreements.</p>
        
        <h2 className="text-2xl font-serif text-luxe-black mt-12 mb-6">4. Security</h2>
        <p>We take reasonable measures to help protect your personal information from loss, theft, misuse, unauthorized access, disclosure, alteration, and destruction.</p>
        
        <h2 className="text-2xl font-serif text-luxe-black mt-12 mb-6">5. Contact Us</h2>
        <p>If you have any questions about this Privacy Policy, please contact us at privacy@premierestates.com.</p>
      </motion.div>
    </div>
  );
}

export function Terms() {
  return (
    <div className="pt-32 pb-24 px-6 md:px-12 max-w-4xl mx-auto min-h-screen">
      <motion.span
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-gold-400 font-medium tracking-[0.2em] uppercase text-sm mb-4 block"
      >
        Legal Information
      </motion.span>
      <motion.h1
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1 }}
        className="text-4xl md:text-6xl font-serif text-luxe-black leading-tight mb-16"
      >
        Terms of <span className="italic font-light">Service</span>
      </motion.h1>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
        className="prose prose-lg text-gray-600 font-light leading-relaxed max-w-none"
      >
        <p>Last updated: October 2023</p>
        
        <h2 className="text-2xl font-serif text-luxe-black mt-12 mb-6">1. Acceptance of Terms</h2>
        <p>By accessing or using the Premier Estates website and services, you agree to be bound by these Terms of Service and all applicable laws and regulations. If you do not agree with any part of these terms, you may not use our services.</p>
        
        <h2 className="text-2xl font-serif text-luxe-black mt-12 mb-6">2. Use License</h2>
        <p>Permission is granted to temporarily download one copy of the materials (information or software) on Premier Estates' website for personal, non-commercial transitory viewing only. This is the grant of a license, not a transfer of title.</p>
        
        <h2 className="text-2xl font-serif text-luxe-black mt-12 mb-6">3. Property Information</h2>
        <p>While we strive to provide accurate and up-to-date information regarding properties, we make no warranties or representations as to the accuracy, completeness, or reliability of any property descriptions, pricing, or availability. All information is subject to change without notice.</p>
        
        <h2 className="text-2xl font-serif text-luxe-black mt-12 mb-6">4. Limitations</h2>
        <p>In no event shall Premier Estates or its suppliers be liable for any damages (including, without limitation, damages for loss of data or profit, or due to business interruption) arising out of the use or inability to use the materials on our website.</p>
        
        <h2 className="text-2xl font-serif text-luxe-black mt-12 mb-6">5. Governing Law</h2>
        <p>These terms and conditions are governed by and construed in accordance with the laws of the jurisdiction in which Premier Estates is headquartered, and you irrevocably submit to the exclusive jurisdiction of the courts in that location.</p>
      </motion.div>
    </div>
  );
}
