import { useParams, Link } from 'react-router-dom';
import { motion } from 'motion/react';
import { properties } from '@/data/mockData';
import { Bed, Bath, Square, MapPin, ArrowLeft, Phone, Mail } from 'lucide-react';
import { formatCurrency } from '@/lib/utils';
import useEmblaCarousel from 'embla-carousel-react';

export function PropertyDetails() {
  const { id } = useParams();
  const property = properties.find(p => p.id === id);
  const [emblaRef] = useEmblaCarousel({ loop: true });

  if (!property) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-4xl font-serif mb-4">Property Not Found</h1>
          <Link to="/properties" className="text-gold-400 hover:underline uppercase tracking-wider text-sm">Return to Portfolio</Link>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white">
      {/* Hero Gallery */}
      <div className="relative h-[70vh] w-full overflow-hidden mt-20" ref={emblaRef}>
        <div className="flex h-full">
          {property.images.map((img, i) => (
            <div key={i} className="flex-[0_0_100%] min-w-0 relative h-full">
              <img
                src={img}
                alt={`${property.title} - View ${i + 1}`}
                className="w-full h-full object-cover"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-black/20" />
            </div>
          ))}
        </div>
        
        <div className="absolute top-8 left-8 z-10">
          <Link to="/properties" className="flex items-center gap-2 text-white hover:text-gold-400 transition-colors bg-black/50 backdrop-blur-md px-4 py-2 rounded-full text-sm uppercase tracking-wider">
            <ArrowLeft className="w-4 h-4" /> Back to Portfolio
          </Link>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-6 md:px-12 py-24">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-16">
          
          {/* Main Details */}
          <div className="lg:col-span-2">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="mb-12"
            >
              <div className="flex items-center gap-4 mb-6">
                <span className="bg-luxe-black text-white text-xs font-medium px-3 py-1 uppercase tracking-wider">
                  {property.status}
                </span>
                <span className="bg-gray-100 text-gray-600 text-xs font-medium px-3 py-1 uppercase tracking-wider">
                  {property.category}
                </span>
              </div>
              
              <h1 className="text-4xl md:text-6xl font-serif text-luxe-black leading-tight mb-6">
                {property.title}
              </h1>
              
              <div className="flex items-center gap-2 text-gray-500 text-lg mb-8">
                <MapPin className="w-5 h-5 text-gold-400" />
                <span className="uppercase tracking-wider">{property.location}</span>
              </div>
              
              <p className="text-4xl font-serif text-gold-400 mb-12">
                {formatCurrency(property.price)}
              </p>

              <div className="grid grid-cols-3 gap-8 py-8 border-y border-gray-200 mb-12">
                <div className="flex flex-col items-center justify-center text-center gap-2">
                  <Bed className="w-8 h-8 text-gray-400" />
                  <span className="text-2xl font-serif text-luxe-black">{property.beds}</span>
                  <span className="text-xs uppercase tracking-widest text-gray-500">Bedrooms</span>
                </div>
                <div className="flex flex-col items-center justify-center text-center gap-2 border-x border-gray-200">
                  <Bath className="w-8 h-8 text-gray-400" />
                  <span className="text-2xl font-serif text-luxe-black">{property.baths}</span>
                  <span className="text-xs uppercase tracking-widest text-gray-500">Bathrooms</span>
                </div>
                <div className="flex flex-col items-center justify-center text-center gap-2">
                  <Square className="w-8 h-8 text-gray-400" />
                  <span className="text-2xl font-serif text-luxe-black">{property.sqft.toLocaleString()}</span>
                  <span className="text-xs uppercase tracking-widest text-gray-500">Square Feet</span>
                </div>
              </div>

              <div>
                <h3 className="text-2xl font-serif text-luxe-black mb-6">About this Property</h3>
                <p className="text-gray-600 leading-relaxed text-lg font-light">
                  {property.description}
                </p>
              </div>
            </motion.div>
          </div>

          {/* Sidebar */}
          <div className="lg:col-span-1">
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.2 }}
              className="sticky top-32 bg-luxe-gray p-8 border border-gray-200"
            >
              <h3 className="text-xl font-serif text-luxe-black mb-6">Listed By</h3>
              
              <div className="flex items-center gap-4 mb-8">
                <img
                  src={property.agent.image}
                  alt={property.agent.name}
                  className="w-16 h-16 rounded-full object-cover"
                  referrerPolicy="no-referrer"
                />
                <div>
                  <h4 className="font-serif text-lg text-luxe-black">{property.agent.name}</h4>
                  <p className="text-xs text-gray-500 uppercase tracking-wider">Luxe Estates Partner</p>
                </div>
              </div>

              <div className="flex flex-col gap-4 mb-8">
                <a href={`tel:${property.agent.phone}`} className="flex items-center gap-3 text-gray-600 hover:text-gold-400 transition-colors">
                  <Phone className="w-5 h-5" />
                  <span>{property.agent.phone}</span>
                </a>
                <a href="#" className="flex items-center gap-3 text-gray-600 hover:text-gold-400 transition-colors">
                  <Mail className="w-5 h-5" />
                  <span>Contact Agent</span>
                </a>
              </div>

              <Link 
                to={`/contact?propertyId=${property.id}`}
                className="block text-center w-full bg-luxe-black text-white py-4 px-6 uppercase tracking-wider text-sm font-medium hover:bg-gold-400 transition-colors mb-4"
              >
                Schedule a Viewing
              </Link>
              <Link 
                to={`/contact?propertyId=${property.id}`}
                className="block text-center w-full bg-transparent border border-luxe-black text-luxe-black py-4 px-6 uppercase tracking-wider text-sm font-medium hover:bg-luxe-black hover:text-white transition-colors"
              >
                Request Details
              </Link>
            </motion.div>
          </div>

        </div>
      </div>
    </div>
  );
}
