import { motion } from 'motion/react';
import { ArrowRight } from 'lucide-react';

export function Sell() {
  return (
    <div className="pt-32 pb-24 px-6 md:px-12 max-w-7xl mx-auto min-h-screen">
      <motion.span
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-gold-400 font-medium tracking-[0.2em] uppercase text-sm mb-4 block"
      >
        List With Us
      </motion.span>
      <motion.h1
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1 }}
        className="text-4xl md:text-6xl font-serif text-luxe-black leading-tight mb-12"
      >
        Sell Your <span className="italic font-light">Property</span>
      </motion.h1>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-16 items-center mb-24">
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.2 }}
          className="space-y-6 text-lg text-gray-600 font-light leading-relaxed"
        >
          <p>
            When you list your property with Premier Estates, you gain access to a global network of high-net-worth individuals and an unparalleled marketing strategy designed to showcase your home to the right audience.
          </p>
          <p>
            Our bespoke approach ensures that every detail, from professional photography and videography to targeted digital campaigns and exclusive print publications, is executed flawlessly.
          </p>
          <p>
            We understand the nuances of the luxury market and provide discreet, expert guidance throughout the entire selling process, maximizing the value of your asset.
          </p>
          <div className="pt-8 mt-8 border-t border-gray-200">
            <a href="/contact" className="inline-flex items-center px-8 py-4 bg-luxe-black text-white hover:bg-gold-400 transition-colors uppercase tracking-wider text-sm font-medium">
              Request a Valuation <ArrowRight className="ml-2 w-4 h-4" />
            </a>
          </div>
        </motion.div>
        <motion.div
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.3 }}
        >
          <img 
            src="https://images.unsplash.com/photo-1600566753190-17f0baa2a6c3?auto=format&fit=crop&q=80&w=1200" 
            alt="Luxury Home Interior" 
            className="w-full h-[600px] object-cover"
          />
        </motion.div>
      </div>
    </div>
  );
}
