import { motion } from 'motion/react';

export function AboutAgency() {
  return (
    <div className="pt-32 pb-24 px-6 md:px-12 max-w-7xl mx-auto min-h-screen">
      <motion.span
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-gold-400 font-medium tracking-[0.2em] uppercase text-sm mb-4 block"
      >
        Our Story
      </motion.span>
      <motion.h1
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1 }}
        className="text-4xl md:text-6xl font-serif text-luxe-black leading-tight mb-12"
      >
        Redefining <span className="italic font-light">Luxury</span> Real Estate
      </motion.h1>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-16 items-center mb-24">
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.2 }}
        >
          <img 
            src="https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?auto=format&fit=crop&q=80&w=1200" 
            alt="Luxury Home" 
            className="w-full h-[600px] object-cover"
          />
        </motion.div>
        <motion.div
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.3 }}
          className="space-y-6 text-lg text-gray-600 font-light leading-relaxed"
        >
          <p>
            Founded in 2010, Premier Estates has established itself as the world's leading luxury real estate agency, specializing in the most exclusive properties across the globe.
          </p>
          <p>
            Our mission is simple: to provide an unparalleled level of service, discretion, and expertise to our discerning clientele. Whether you are seeking a penthouse in Manhattan, a villa in Dubai, or a historic estate in London, our global network of elite agents is dedicated to finding your perfect home.
          </p>
          <p>
            We believe that luxury is not just about price; it's about an experience. From our bespoke marketing strategies to our white-glove concierge services, every aspect of Premier Estates is designed to exceed your expectations.
          </p>
          <div className="pt-8 grid grid-cols-2 gap-8 border-t border-gray-200 mt-8">
            <div>
              <div className="text-4xl font-serif text-luxe-black mb-2">$10B+</div>
              <div className="text-sm uppercase tracking-wider text-gray-400">Sales Volume</div>
            </div>
            <div>
              <div className="text-4xl font-serif text-luxe-black mb-2">50+</div>
              <div className="text-sm uppercase tracking-wider text-gray-400">Global Offices</div>
            </div>
          </div>
        </motion.div>
      </div>
    </div>
  );
}
