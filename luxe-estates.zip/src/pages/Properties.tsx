import { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { PropertyCard } from '@/components/ui/PropertyCard';
import { properties } from '@/data/mockData';
import { Search, SlidersHorizontal, MapPin, Home, X } from 'lucide-react';
import { useSearchParams } from 'react-router-dom';

export function Properties() {
  const [searchParams] = useSearchParams();
  const categoryParam = searchParams.get('category') || 'All';
  const locationParam = searchParams.get('location') || '';
  const typeParam = searchParams.get('type') || 'All Types';
  const statusParam = searchParams.get('status') || 'All';
  
  // Normalize category (e.g., "Villas" -> "Villa")
  const normalizedCategory = categoryParam.endsWith('s') ? categoryParam.slice(0, -1) : categoryParam;
  const initialFilter = normalizedCategory !== 'All' ? normalizedCategory : (typeParam !== 'All Types' ? typeParam : 'All');

  const [filter, setFilter] = useState(initialFilter);
  const [searchQuery, setSearchQuery] = useState(locationParam);
  const [isSearchFocused, setIsSearchFocused] = useState(false);
  const searchContainerRef = useRef<HTMLDivElement>(null);
  
  // Advanced filters
  const [showFilters, setShowFilters] = useState(false);
  const [statusFilter, setStatusFilter] = useState(statusParam);
  const [minPrice, setMinPrice] = useState('');
  const [maxPrice, setMaxPrice] = useState('');
  const [beds, setBeds] = useState('Any');
  
  useEffect(() => {
    if (categoryParam !== 'All') {
      setFilter(categoryParam.endsWith('s') ? categoryParam.slice(0, -1) : categoryParam);
    } else if (typeParam !== 'All Types') {
      setFilter(typeParam);
    }
    if (locationParam) {
      setSearchQuery(locationParam);
    }
    if (statusParam !== 'All') {
      setStatusFilter(statusParam);
    }
  }, [categoryParam, typeParam, locationParam, statusParam]);

  // Handle click outside to close suggestions
  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (searchContainerRef.current && !searchContainerRef.current.contains(event.target as Node)) {
        setIsSearchFocused(false);
      }
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  const filteredProperties = properties.filter(p => {
    const matchCategory = filter === 'All' || p.category === filter;
    const matchSearch = p.location.toLowerCase().includes(searchQuery.toLowerCase()) || p.title.toLowerCase().includes(searchQuery.toLowerCase());
    const matchStatus = statusFilter === 'All' || p.status === statusFilter;
    const matchMinPrice = minPrice === '' || p.price >= parseInt(minPrice);
    const matchMaxPrice = maxPrice === '' || p.price <= parseInt(maxPrice);
    const matchBeds = beds === 'Any' || p.beds >= parseInt(beds);
    
    return matchCategory && matchSearch && matchStatus && matchMinPrice && matchMaxPrice && matchBeds;
  });

  // Generate suggestions
  const uniqueLocations = Array.from(new Set(properties.map(p => p.location)));
  const uniqueTitles = properties.map(p => p.title);
  
  const locationSuggestions = uniqueLocations.filter(loc => loc.toLowerCase().includes(searchQuery.toLowerCase())).slice(0, 3);
  const titleSuggestions = uniqueTitles.filter(title => title.toLowerCase().includes(searchQuery.toLowerCase())).slice(0, 3);
  
  const showSuggestions = isSearchFocused && (locationSuggestions.length > 0 || titleSuggestions.length > 0);

  const handleSuggestionClick = (suggestion: string) => {
    setSearchQuery(suggestion);
    setIsSearchFocused(false);
  };

  return (
    <div className="pt-32 pb-24 px-6 md:px-12 max-w-7xl mx-auto min-h-screen relative">
      <div className="flex flex-col md:flex-row justify-between items-end mb-16 gap-8">
        <div>
          <motion.span
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-gold-400 font-medium tracking-[0.2em] uppercase text-sm mb-4 block"
          >
            Global Portfolio
          </motion.span>
          <motion.h1
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="text-4xl md:text-6xl font-serif text-luxe-black leading-tight"
          >
            Exclusive <span className="italic font-light">Listings</span>
          </motion.h1>
        </div>
        
        <motion.div
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.2 }}
          className="flex gap-4 w-full md:w-auto"
        >
          <div className="relative flex-grow md:w-80" ref={searchContainerRef}>
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
            <input 
              type="text" 
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              onFocus={() => setIsSearchFocused(true)}
              placeholder="Search properties or locations..." 
              className="w-full pl-10 pr-4 py-3 border border-gray-200 focus:border-gold-400 focus:outline-none bg-transparent transition-colors text-sm"
            />
            
            {/* Suggestions Dropdown */}
            <AnimatePresence>
              {showSuggestions && (
                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: 10 }}
                  className="absolute top-full left-0 right-0 mt-2 bg-white border border-gray-100 shadow-xl z-50 max-h-80 overflow-y-auto"
                >
                  {locationSuggestions.length > 0 && (
                    <div className="p-2">
                      <div className="text-xs uppercase tracking-wider text-gray-400 font-medium px-3 py-2">Locations</div>
                      {locationSuggestions.map(loc => (
                        <button
                          key={loc}
                          onClick={() => handleSuggestionClick(loc)}
                          className="w-full text-left px-3 py-2 text-sm text-luxe-black hover:bg-luxe-gray hover:text-gold-500 transition-colors flex items-center gap-2"
                        >
                          <MapPin className="w-3 h-3 text-gray-400" />
                          {loc}
                        </button>
                      ))}
                    </div>
                  )}
                  
                  {titleSuggestions.length > 0 && (
                    <div className="p-2 border-t border-gray-100">
                      <div className="text-xs uppercase tracking-wider text-gray-400 font-medium px-3 py-2">Properties</div>
                      {titleSuggestions.map(title => (
                        <button
                          key={title}
                          onClick={() => handleSuggestionClick(title)}
                          className="w-full text-left px-3 py-2 text-sm text-luxe-black hover:bg-luxe-gray hover:text-gold-500 transition-colors flex items-center gap-2"
                        >
                          <Home className="w-3 h-3 text-gray-400" />
                          {title}
                        </button>
                      ))}
                    </div>
                  )}
                </motion.div>
              )}
            </AnimatePresence>
          </div>
          <button 
            onClick={() => setShowFilters(!showFilters)}
            className={`border p-3 transition-colors flex items-center justify-center ${showFilters ? 'bg-luxe-black text-white border-luxe-black' : 'border-gray-200 hover:border-gold-400 hover:text-gold-400'}`}
          >
            <SlidersHorizontal className="w-5 h-5" />
          </button>
        </motion.div>
      </div>

      {/* Advanced Filters Panel */}
      <AnimatePresence>
        {showFilters && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            className="overflow-hidden mb-12"
          >
            <div className="bg-luxe-gray p-8 border border-gray-100 grid grid-cols-1 md:grid-cols-4 gap-6">
              <div>
                <label className="block text-xs uppercase tracking-wider text-gray-500 font-medium mb-2">Status</label>
                <select 
                  value={statusFilter}
                  onChange={(e) => setStatusFilter(e.target.value)}
                  className="w-full px-4 py-3 bg-white border border-gray-200 focus:border-gold-400 focus:outline-none transition-colors appearance-none"
                >
                  <option value="All">All Status</option>
                  <option value="For Sale">For Sale</option>
                  <option value="For Rent">For Rent</option>
                </select>
              </div>
              <div>
                <label className="block text-xs uppercase tracking-wider text-gray-500 font-medium mb-2">Min Price ($)</label>
                <input 
                  type="number" 
                  value={minPrice}
                  onChange={(e) => setMinPrice(e.target.value)}
                  placeholder="Any"
                  className="w-full px-4 py-3 bg-white border border-gray-200 focus:border-gold-400 focus:outline-none transition-colors"
                />
              </div>
              <div>
                <label className="block text-xs uppercase tracking-wider text-gray-500 font-medium mb-2">Max Price ($)</label>
                <input 
                  type="number" 
                  value={maxPrice}
                  onChange={(e) => setMaxPrice(e.target.value)}
                  placeholder="Any"
                  className="w-full px-4 py-3 bg-white border border-gray-200 focus:border-gold-400 focus:outline-none transition-colors"
                />
              </div>
              <div>
                <label className="block text-xs uppercase tracking-wider text-gray-500 font-medium mb-2">Bedrooms</label>
                <select 
                  value={beds}
                  onChange={(e) => setBeds(e.target.value)}
                  className="w-full px-4 py-3 bg-white border border-gray-200 focus:border-gold-400 focus:outline-none transition-colors appearance-none"
                >
                  <option value="Any">Any</option>
                  <option value="2">2+</option>
                  <option value="4">4+</option>
                  <option value="6">6+</option>
                  <option value="8">8+</option>
                </select>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <div className="flex gap-4 mb-12 overflow-x-auto no-scrollbar pb-4">
        {['All', 'Villa', 'Penthouse', 'Mansion', 'Apartment'].map((cat) => (
          <button
            key={cat}
            onClick={() => setFilter(cat)}
            className={`px-6 py-2 text-sm uppercase tracking-wider whitespace-nowrap transition-colors ${
              filter === cat 
                ? 'bg-luxe-black text-white' 
                : 'border border-gray-200 text-gray-600 hover:border-gold-400 hover:text-gold-400'
            }`}
          >
            {cat}
          </button>
        ))}
      </div>

      {filteredProperties.length === 0 ? (
        <div className="text-center py-20">
          <h3 className="text-2xl font-serif text-luxe-black mb-2">No properties found</h3>
          <p className="text-gray-500">Try adjusting your search or filters to find what you're looking for.</p>
          <button 
            onClick={() => {
              setFilter('All');
              setSearchQuery('');
              setStatusFilter('All');
              setMinPrice('');
              setMaxPrice('');
              setBeds('Any');
            }}
            className="mt-6 text-gold-400 hover:text-gold-500 uppercase tracking-wider text-sm font-medium transition-colors"
          >
            Clear all filters
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredProperties.map((property, index) => (
            <PropertyCard key={property.id} property={property} index={index} />
          ))}
        </div>
      )}
    </div>
  );
}
