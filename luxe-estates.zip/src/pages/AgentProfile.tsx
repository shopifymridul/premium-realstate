import { motion } from 'motion/react';
import { useParams, Link } from 'react-router-dom';
import { agents, properties } from '@/data/mockData';
import { Mail, Phone, Instagram, Linkedin, ArrowLeft } from 'lucide-react';
import { PropertyCard } from '@/components/ui/PropertyCard';

export function AgentProfile() {
  const { id } = useParams();
  const agent = agents.find(a => a.id.toString() === id);

  if (!agent) {
    return (
      <div className="min-h-screen flex items-center justify-center pt-20">
        <div className="text-center">
          <h1 className="text-4xl font-serif text-luxe-black mb-4">Agent Not Found</h1>
          <Link to="/agents" className="text-gold-400 hover:text-gold-500 transition-colors flex items-center gap-2 justify-center">
            <ArrowLeft className="w-4 h-4" />
            Back to Agents
          </Link>
        </div>
      </div>
    );
  }

  // Mock agent's listings (just taking the first 3 for demo)
  const agentListings = properties.slice(0, 3);

  return (
    <div className="pt-32 pb-24 px-6 md:px-12 max-w-7xl mx-auto min-h-screen">
      <Link to="/agents" className="inline-flex items-center gap-2 text-gray-500 hover:text-gold-400 transition-colors mb-12 uppercase tracking-wider text-sm">
        <ArrowLeft className="w-4 h-4" />
        Back to Team
      </Link>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-24 mb-24">
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          className="lg:col-span-5"
        >
          <div className="relative aspect-[3/4] overflow-hidden">
            <img
              src={agent.image}
              alt={agent.name}
              className="w-full h-full object-cover"
              loading="lazy"
              referrerPolicy="no-referrer"
            />
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.1 }}
          className="lg:col-span-7 flex flex-col justify-center"
        >
          <span className="text-gold-400 font-medium tracking-[0.2em] uppercase text-sm mb-4 block">
            {agent.role}
          </span>
          <h1 className="text-4xl md:text-6xl font-serif text-luxe-black leading-tight mb-8">
            {agent.name}
          </h1>
          
          <div className="prose prose-lg text-gray-600 font-light mb-12">
            <p className="mb-6">
              With over a decade of experience in the luxury real estate market, {agent.name.split(' ')[0]} has established a reputation for unparalleled market knowledge and an unwavering commitment to client success. Specializing in high-end properties, they have consistently ranked among the top producers in the region.
            </p>
            <p>
              Their approach is built on discretion, integrity, and a deep understanding of the unique needs of high-net-worth individuals. Whether you are seeking a sprawling estate, a modern penthouse, or a lucrative investment opportunity, {agent.name.split(' ')[0]} provides personalized guidance every step of the way.
            </p>
          </div>

          <div className="grid grid-cols-2 gap-8 mb-12 py-8 border-y border-gray-200">
            <div>
              <p className="text-sm text-gray-500 uppercase tracking-wider mb-1">Career Sales</p>
              <p className="text-3xl font-serif text-luxe-black">{agent.sales}</p>
            </div>
            <div>
              <p className="text-sm text-gray-500 uppercase tracking-wider mb-1">Experience</p>
              <p className="text-3xl font-serif text-luxe-black">12+ Years</p>
            </div>
          </div>

          <div className="flex flex-col sm:flex-row gap-6">
            <a 
              href={`mailto:${agent.email}`}
              className="flex-1 bg-luxe-black text-white py-4 px-6 text-center uppercase tracking-wider text-sm font-medium hover:bg-gold-400 transition-colors flex items-center justify-center gap-2"
            >
              <Mail className="w-4 h-4" />
              Email Agent
            </a>
            <a 
              href={`tel:${agent.phone}`}
              className="flex-1 bg-transparent border border-luxe-black text-luxe-black py-4 px-6 text-center uppercase tracking-wider text-sm font-medium hover:bg-luxe-black hover:text-white transition-colors flex items-center justify-center gap-2"
            >
              <Phone className="w-4 h-4" />
              Call Agent
            </a>
          </div>

          <div className="flex gap-6 mt-8 text-gray-400">
            <a href="#" className="hover:text-gold-400 transition-colors">
              <Instagram className="w-5 h-5" />
            </a>
            <a href="#" className="hover:text-gold-400 transition-colors">
              <Linkedin className="w-5 h-5" />
            </a>
          </div>
        </motion.div>
      </div>

      <div>
        <div className="flex justify-between items-end mb-12">
          <h2 className="text-3xl font-serif text-luxe-black">Active <span className="italic font-light">Listings</span></h2>
          <Link to="/properties" className="text-sm uppercase tracking-wider font-medium text-gold-400 hover:text-luxe-black transition-colors flex items-center gap-2">
            View All
            <ArrowLeft className="w-4 h-4 rotate-180" />
          </Link>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {agentListings.map((property, index) => (
            <motion.div
              key={property.id}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
            >
              <PropertyCard property={property} />
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );
}
