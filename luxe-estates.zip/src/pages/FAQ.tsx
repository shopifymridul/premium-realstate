import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ChevronDown } from 'lucide-react';

const faqs = [
  {
    question: "What is the process for buying a property?",
    answer: "Our buying process is tailored to your specific needs. It begins with a private consultation to understand your requirements, followed by curated property viewings, expert negotiation, and seamless closing assistance."
  },
  {
    question: "Do you offer off-market properties?",
    answer: "Yes, a significant portion of our portfolio consists of off-market properties available exclusively to our registered clients. Please contact an agent to discuss these discreet listings."
  },
  {
    question: "How do you value luxury properties?",
    answer: "We utilize a comprehensive approach that considers current market trends, comparable sales, unique property features, and our extensive global network to determine the most accurate and competitive valuation."
  },
  {
    question: "Can you assist with international purchases?",
    answer: "Absolutely. With offices in over 50 countries, our global team is well-equipped to handle cross-border transactions, providing guidance on local regulations, taxes, and financing."
  },
  {
    question: "What fees are involved in selling my property?",
    answer: "Our commission structure is competitive and reflects the premium service we provide. Specific fees are discussed during your initial consultation and depend on the property and marketing strategy."
  }
];

export function FAQ() {
  const [openIndex, setOpenIndex] = useState<number | null>(null);

  return (
    <div className="pt-32 pb-24 px-6 md:px-12 max-w-4xl mx-auto min-h-screen">
      <motion.span
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-gold-400 font-medium tracking-[0.2em] uppercase text-sm mb-4 block text-center"
      >
        Support & Information
      </motion.span>
      <motion.h1
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1 }}
        className="text-4xl md:text-6xl font-serif text-luxe-black leading-tight mb-16 text-center"
      >
        Frequently Asked <span className="italic font-light">Questions</span>
      </motion.h1>

      <div className="space-y-4">
        {faqs.map((faq, index) => (
          <motion.div
            key={index}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 + index * 0.1 }}
            className="border border-gray-200 bg-white"
          >
            <button
              onClick={() => setOpenIndex(openIndex === index ? null : index)}
              className="w-full px-6 py-5 flex items-center justify-between text-left focus:outline-none"
            >
              <span className="text-lg font-medium text-luxe-black">{faq.question}</span>
              <ChevronDown 
                className={`w-5 h-5 text-gold-400 transition-transform duration-300 ${openIndex === index ? 'rotate-180' : ''}`}
              />
            </button>
            <AnimatePresence>
              {openIndex === index && (
                <motion.div
                  initial={{ height: 0, opacity: 0 }}
                  animate={{ height: 'auto', opacity: 1 }}
                  exit={{ height: 0, opacity: 0 }}
                  className="overflow-hidden"
                >
                  <div className="px-6 pb-5 text-gray-600 font-light leading-relaxed">
                    {faq.answer}
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </motion.div>
        ))}
      </div>
    </div>
  );
}
