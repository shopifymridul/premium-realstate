import React, { useState } from 'react';
import { motion } from 'motion/react';
import { useParams, Link } from 'react-router-dom';
import { ArrowLeft, Heart, Share2, MessageCircle, Send, Edit2, Trash2, Check, X } from 'lucide-react';
import { articles } from '@/data/mockArticles';

export function Article() {
  const { slug } = useParams();
  const article = articles.find(a => a.id === Number(slug)) || articles[0];

  const [likes, setLikes] = useState(124);
  const [isLiked, setIsLiked] = useState(false);
  const [comments, setComments] = useState([
    { id: 1, author: "Jane Doe", text: "Fascinating insights on the market!", date: "2 days ago", isOwn: false },
    { id: 2, author: "John Smith", text: "I completely agree with the points made here.", date: "1 day ago", isOwn: false }
  ]);
  const [newComment, setNewComment] = useState("");
  const [editingId, setEditingId] = useState<number | null>(null);
  const [editText, setEditText] = useState("");

  const handleLike = () => {
    if (isLiked) {
      setLikes(l => l - 1);
      setIsLiked(false);
    } else {
      setLikes(l => l + 1);
      setIsLiked(true);
    }
  };

  const handleShare = () => {
    if (navigator.share) {
      navigator.share({
        title: article.title,
        text: article.excerpt,
        url: window.location.href,
      }).catch(console.error);
    } else {
      navigator.clipboard.writeText(window.location.href);
      alert("Link copied to clipboard!");
    }
  };

  const handleCommentSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newComment.trim()) return;
    
    setComments([
      ...comments,
      {
        id: Date.now(),
        author: "Guest User",
        text: newComment,
        date: "Just now",
        isOwn: true
      }
    ]);
    setNewComment("");
  };

  const startEdit = (id: number, text: string) => {
    setEditingId(id);
    setEditText(text);
  };

  const cancelEdit = () => {
    setEditingId(null);
    setEditText("");
  };

  const saveEdit = (id: number) => {
    if (!editText.trim()) return;
    setComments(comments.map(c => c.id === id ? { ...c, text: editText } : c));
    setEditingId(null);
    setEditText("");
  };

  const deleteComment = (id: number) => {
    setComments(comments.filter(c => c.id !== id));
  };

  return (
    <div className="pt-32 pb-24 px-6 md:px-12 max-w-4xl mx-auto min-h-screen">
      <Link to="/blog" className="inline-flex items-center text-sm uppercase tracking-wider font-medium text-gray-500 hover:text-gold-400 transition-colors mb-12">
        <ArrowLeft className="mr-2 w-4 h-4" /> Back to Journal
      </Link>
      
      <motion.span
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-gold-400 font-medium tracking-[0.2em] uppercase text-sm mb-4 block"
      >
        {article.category}
      </motion.span>
      <motion.h1
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1 }}
        className="text-4xl md:text-6xl font-serif text-luxe-black leading-tight mb-8"
      >
        {article.title}
      </motion.h1>
      
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
        className="flex items-center gap-4 text-sm text-gray-400 mb-12"
      >
        <span>{article.date}</span>
        <span>•</span>
        <span>5 min read</span>
      </motion.div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.3 }}
      >
        <img 
          src={article.image} 
          alt={article.title} 
          className="w-full h-[500px] object-cover mb-12"
        />
      </motion.div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.4 }}
        className="prose prose-lg text-gray-600 font-light leading-relaxed max-w-none mb-16"
      >
        <p className="text-xl leading-relaxed text-luxe-black mb-8">
          {article.excerpt}
        </p>
        
        <p>
          In recent years, the luxury real estate market has seen a significant shift towards properties that offer more than just a place to live. Buyers are increasingly looking for homes that provide a comprehensive lifestyle experience, complete with world-class amenities and unparalleled convenience.
        </p>
        
        <h2 className="text-2xl font-serif text-luxe-black mt-12 mb-6">The Changing Landscape</h2>
        <p>
          For high-net-worth individuals, time is the ultimate luxury. Properties that cater to this by providing turnkey solutions—combining the comforts of a private home with five-star services—are in higher demand than ever. From 24/7 concierge and room service to private spas and Michelin-starred dining, these properties offer an unparalleled level of convenience.
        </p>
        
        <h2 className="text-2xl font-serif text-luxe-black mt-12 mb-6">Investment Potential</h2>
        <p>
          Beyond the lifestyle benefits, these properties also present a compelling investment opportunity. The association with prestige often commands a premium on the purchase price, and these properties tend to hold their value exceptionally well. Furthermore, many offer rental programs, allowing owners to generate income when they are not using the property.
        </p>
        
        <h2 className="text-2xl font-serif text-luxe-black mt-12 mb-6">Looking Ahead</h2>
        <p>
          As the demand for luxury and convenience continues to grow, we can expect to see even more innovative projects entering the market. From urban high-rises to secluded resort villas, the future of luxury living is undoubtedly focused on holistic, service-rich environments.
        </p>
      </motion.div>

      {/* Interaction Bar */}
      <div className="border-t border-b border-gray-200 py-6 mb-16 flex items-center justify-between">
        <div className="flex items-center gap-6">
          <button 
            onClick={handleLike}
            className={`flex items-center gap-2 transition-colors ${isLiked ? 'text-red-500' : 'text-gray-500 hover:text-red-500'}`}
          >
            <Heart className={`w-6 h-6 ${isLiked ? 'fill-current' : ''}`} />
            <span className="font-medium">{likes}</span>
          </button>
          <div className="flex items-center gap-2 text-gray-500">
            <MessageCircle className="w-6 h-6" />
            <span className="font-medium">{comments.length}</span>
          </div>
        </div>
        <button 
          onClick={handleShare}
          className="flex items-center gap-2 text-gray-500 hover:text-gold-400 transition-colors"
        >
          <Share2 className="w-6 h-6" />
          <span className="font-medium uppercase tracking-wider text-sm">Share</span>
        </button>
      </div>

      {/* Comments Section */}
      <div className="max-w-2xl">
        <h3 className="text-2xl font-serif text-luxe-black mb-8">Comments ({comments.length})</h3>
        
        <form onSubmit={handleCommentSubmit} className="mb-12">
          <div className="relative">
            <textarea
              value={newComment}
              onChange={(e) => setNewComment(e.target.value)}
              placeholder="Add a comment..."
              className="w-full border border-gray-200 p-4 pr-12 focus:border-gold-400 focus:outline-none resize-none h-32 bg-gray-50/50"
            />
            <button 
              type="submit"
              disabled={!newComment.trim()}
              className="absolute bottom-4 right-4 text-gold-400 hover:text-gold-500 disabled:opacity-50 disabled:hover:text-gold-400 transition-colors"
            >
              <Send className="w-5 h-5" />
            </button>
          </div>
        </form>

        <div className="space-y-8">
          {comments.map((comment) => (
            <div key={comment.id} className="flex gap-4 group">
              <div className="w-10 h-10 rounded-full bg-gray-200 flex items-center justify-center shrink-0">
                <span className="text-gray-500 font-medium">{comment.author.charAt(0)}</span>
              </div>
              <div className="flex-grow">
                <div className="flex items-baseline justify-between mb-1">
                  <div className="flex items-baseline gap-3">
                    <span className="font-medium text-luxe-black">{comment.author}</span>
                    <span className="text-xs text-gray-400">{comment.date}</span>
                  </div>
                  {comment.isOwn && editingId !== comment.id && (
                    <div className="flex items-center gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                      <button onClick={() => startEdit(comment.id, comment.text)} className="text-gray-400 hover:text-gold-400">
                        <Edit2 className="w-4 h-4" />
                      </button>
                      <button onClick={() => deleteComment(comment.id)} className="text-gray-400 hover:text-red-500">
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  )}
                </div>
                
                {editingId === comment.id ? (
                  <div className="mt-2">
                    <textarea
                      value={editText}
                      onChange={(e) => setEditText(e.target.value)}
                      className="w-full border border-gray-200 p-3 focus:border-gold-400 focus:outline-none resize-none h-24 bg-white"
                    />
                    <div className="flex items-center gap-2 mt-2">
                      <button 
                        onClick={() => saveEdit(comment.id)}
                        className="bg-gold-400 text-white px-3 py-1.5 text-sm font-medium hover:bg-gold-500 transition-colors flex items-center gap-1"
                      >
                        <Check className="w-4 h-4" /> Save
                      </button>
                      <button 
                        onClick={cancelEdit}
                        className="bg-gray-100 text-gray-600 px-3 py-1.5 text-sm font-medium hover:bg-gray-200 transition-colors flex items-center gap-1"
                      >
                        <X className="w-4 h-4" /> Cancel
                      </button>
                    </div>
                  </div>
                ) : (
                  <p className="text-gray-600 font-light whitespace-pre-wrap">{comment.text}</p>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
