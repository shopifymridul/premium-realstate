import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Mail, Phone, MapPin, Send } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useSearchParams } from 'react-router-dom';

export function Contact() {
  const [searchParams] = useSearchParams();
  const propertyId = searchParams.get('propertyId');

  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    interest: propertyId ? 'Schedule Viewing' : 'General Inquiry',
    message: propertyId ? `I am interested in property ID: ${propertyId}` : ''
  });
  const [status, setStatus] = useState<'idle' | 'submitting' | 'success' | 'error'>('idle');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setStatus('submitting');

    try {
      const { error } = await supabase
        .from('contacts')
        .insert([formData]);

      if (error) throw error;
      
      setStatus('success');
      setFormData({ name: '', email: '', phone: '', interest: 'General Inquiry', message: '' });
    } catch (error) {
      console.error('Error submitting form:', error);
      setStatus('error');
    }
  };

  return (
    <div className="pt-32 pb-24 px-6 md:px-12 max-w-7xl mx-auto min-h-screen">
      <div className="mb-16">
        <motion.span
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-gold-400 font-medium tracking-[0.2em] uppercase text-sm mb-4 block"
        >
          Get in Touch
        </motion.span>
        <motion.h1
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="text-4xl md:text-6xl font-serif text-luxe-black leading-tight"
        >
          Contact <span className="italic font-light">Us</span>
        </motion.h1>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-16">
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.2 }}
        >
          <h2 className="text-2xl font-serif text-luxe-black mb-8">Send a Message</h2>
          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label htmlFor="name" className="block text-sm font-medium text-gray-700 mb-2">Full Name</label>
                <input
                  type="text"
                  id="name"
                  required
                  value={formData.name}
                  onChange={e => setFormData(prev => ({ ...prev, name: e.target.value }))}
                  className="w-full px-4 py-3 bg-luxe-gray border border-gray-200 focus:border-gold-400 focus:ring-1 focus:ring-gold-400 outline-none transition-colors"
                  placeholder="John Doe"
                />
              </div>
              <div>
                <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-2">Email Address</label>
                <input
                  type="email"
                  id="email"
                  required
                  value={formData.email}
                  onChange={e => setFormData(prev => ({ ...prev, email: e.target.value }))}
                  className="w-full px-4 py-3 bg-luxe-gray border border-gray-200 focus:border-gold-400 focus:ring-1 focus:ring-gold-400 outline-none transition-colors"
                  placeholder="john@example.com"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label htmlFor="phone" className="block text-sm font-medium text-gray-700 mb-2">Phone Number</label>
                <input
                  type="tel"
                  id="phone"
                  value={formData.phone}
                  onChange={e => setFormData(prev => ({ ...prev, phone: e.target.value }))}
                  className="w-full px-4 py-3 bg-luxe-gray border border-gray-200 focus:border-gold-400 focus:ring-1 focus:ring-gold-400 outline-none transition-colors"
                  placeholder="+1 (555) 000-0000"
                />
              </div>
              <div>
                <label htmlFor="interest" className="block text-sm font-medium text-gray-700 mb-2">Area of Interest</label>
                <select
                  id="interest"
                  value={formData.interest}
                  onChange={e => setFormData(prev => ({ ...prev, interest: e.target.value }))}
                  className="w-full px-4 py-3 bg-luxe-gray border border-gray-200 focus:border-gold-400 focus:ring-1 focus:ring-gold-400 outline-none transition-colors appearance-none"
                >
                  <option value="General Inquiry">General Inquiry</option>
                  <option value="Buying">Buying a Property</option>
                  <option value="Selling">Selling a Property</option>
                  <option value="Schedule Viewing">Schedule a Viewing</option>
                  <option value="Careers">Careers</option>
                </select>
              </div>
            </div>

            <div>
              <label htmlFor="message" className="block text-sm font-medium text-gray-700 mb-2">Message</label>
              <textarea
                id="message"
                required
                rows={6}
                value={formData.message}
                onChange={e => setFormData(prev => ({ ...prev, message: e.target.value }))}
                className="w-full px-4 py-3 bg-luxe-gray border border-gray-200 focus:border-gold-400 focus:ring-1 focus:ring-gold-400 outline-none transition-colors resize-none"
                placeholder="How can we help you?"
              ></textarea>
            </div>

            <button
              type="submit"
              disabled={status === 'submitting'}
              className="w-full bg-luxe-black text-white py-4 px-8 uppercase tracking-wider text-sm font-medium hover:bg-gold-400 transition-colors flex items-center justify-center gap-2 disabled:opacity-70 disabled:cursor-not-allowed"
            >
              {status === 'submitting' ? 'Sending...' : 'Send Message'}
              <Send className="w-4 h-4" />
            </button>

            {status === 'success' && (
              <p className="text-green-600 text-sm mt-4">Thank you for your message. We will be in touch shortly.</p>
            )}
            {status === 'error' && (
              <p className="text-red-600 text-sm mt-4">There was an error sending your message. Please try again later.</p>
            )}
          </form>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.3 }}
          className="lg:pl-12"
        >
          <div className="bg-luxe-gray p-12 h-full">
            <h2 className="text-2xl font-serif text-luxe-black mb-8">Global Offices</h2>
            
            <div className="space-y-12">
              <div>
                <h3 className="text-lg font-serif text-luxe-black mb-4">Beverly Hills</h3>
                <ul className="space-y-4 text-gray-600 font-light">
                  <li className="flex items-start gap-4">
                    <MapPin className="w-5 h-5 text-gold-400 shrink-0 mt-1" />
                    <span>90210 Rodeo Drive, Suite 100<br />Beverly Hills, CA 90210</span>
                  </li>
                  <li className="flex items-center gap-4">
                    <Phone className="w-5 h-5 text-gold-400 shrink-0" />
                    <a href="tel:+13105550123" className="hover:text-gold-400 transition-colors">+1 (310) 555-0123</a>
                  </li>
                  <li className="flex items-center gap-4">
                    <Mail className="w-5 h-5 text-gold-400 shrink-0" />
                    <a href="mailto:la@premierestates.com" className="hover:text-gold-400 transition-colors">la@premierestates.com</a>
                  </li>
                </ul>
              </div>

              <div>
                <h3 className="text-lg font-serif text-luxe-black mb-4">London</h3>
                <ul className="space-y-4 text-gray-600 font-light">
                  <li className="flex items-start gap-4">
                    <MapPin className="w-5 h-5 text-gold-400 shrink-0 mt-1" />
                    <span>15 Mayfair Place<br />London W1J 8AJ, UK</span>
                  </li>
                  <li className="flex items-center gap-4">
                    <Phone className="w-5 h-5 text-gold-400 shrink-0" />
                    <a href="tel:+442071234567" className="hover:text-gold-400 transition-colors">+44 20 7123 4567</a>
                  </li>
                  <li className="flex items-center gap-4">
                    <Mail className="w-5 h-5 text-gold-400 shrink-0" />
                    <a href="mailto:london@premierestates.com" className="hover:text-gold-400 transition-colors">london@premierestates.com</a>
                  </li>
                </ul>
              </div>

              <div>
                <h3 className="text-lg font-serif text-luxe-black mb-4">Dubai</h3>
                <ul className="space-y-4 text-gray-600 font-light">
                  <li className="flex items-start gap-4">
                    <MapPin className="w-5 h-5 text-gold-400 shrink-0 mt-1" />
                    <span>Level 112, Burj Khalifa<br />Downtown Dubai, UAE</span>
                  </li>
                  <li className="flex items-center gap-4">
                    <Phone className="w-5 h-5 text-gold-400 shrink-0" />
                    <a href="tel:+97141234567" className="hover:text-gold-400 transition-colors">+971 4 123 4567</a>
                  </li>
                  <li className="flex items-center gap-4">
                    <Mail className="w-5 h-5 text-gold-400 shrink-0" />
                    <a href="mailto:dubai@premierestates.com" className="hover:text-gold-400 transition-colors">dubai@premierestates.com</a>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </div>
  );
}
