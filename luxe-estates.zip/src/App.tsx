import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { Layout } from '@/components/layout/Layout';
import { ScrollToTop } from '@/components/layout/ScrollToTop';
import { Home } from '@/pages/Home';
import { Properties } from '@/pages/Properties';
import { PropertyDetails } from '@/pages/PropertyDetails';
import { Agents } from '@/pages/Agents';
import { AgentProfile } from '@/pages/AgentProfile';
import { Contact } from '@/pages/Contact';
import { AboutAgency } from '@/pages/About';
import { FAQ } from '@/pages/FAQ';
import { Journal } from '@/pages/Journal';
import { Article } from '@/pages/Article';
import { Sell } from '@/pages/Sell';
import { Privacy, Terms } from '@/pages/Legal';
import { MapSearch } from '@/pages/MapSearch';

export default function App() {
  return (
    <Router>
      <ScrollToTop />
      <Routes>
        <Route path="/" element={<Layout />}>
          <Route index element={<Home />} />
          <Route path="properties" element={<Properties />} />
          <Route path="properties/:id" element={<PropertyDetails />} />
          <Route path="buy" element={<Navigate to="/properties?status=For Sale" replace />} />
          <Route path="sell" element={<Sell />} />
          <Route path="rent" element={<Navigate to="/properties?status=For Rent" replace />} />
          <Route path="map-search" element={<MapSearch />} />
          <Route path="agents" element={<Agents />} />
          <Route path="agents/:id" element={<AgentProfile />} />
          <Route path="about" element={<AboutAgency />} />
          <Route path="blog" element={<Journal />} />
          <Route path="blog/:slug" element={<Article />} />
          <Route path="contact" element={<Contact />} />
          <Route path="faq" element={<FAQ />} />
          <Route path="privacy" element={<Privacy />} />
          <Route path="terms" element={<Terms />} />
        </Route>
      </Routes>
    </Router>
  );
}
