import React from 'react';
import { Link } from 'react-router-dom';
import { Bed, Bath, Square, MapPin } from 'lucide-react';
import { motion } from 'motion/react';
import { Property } from '@/data/mockData';
import { formatCurrency } from '@/lib/utils';

interface PropertyCardProps {
  property: Property;
  index?: number;
  key?: React.Key;
}

export function PropertyCard({ property, index = 0 }: PropertyCardProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.6, delay: index * 0.1 }}
      className="group relative bg-white overflow-hidden shadow-sm hover:shadow-2xl transition-all duration-500"
    >
      <Link to={`/properties/${property.id}`} className="block relative aspect-[4/3] overflow-hidden">
        <img
          src={property.images[0]}
          alt={property.title}
          className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
          loading="lazy"
          referrerPolicy="no-referrer"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
        
        {/* Badges */}
        <div className="absolute top-4 left-4 flex flex-col gap-2">
          <span className="bg-luxe-black text-white text-xs font-medium px-3 py-1 uppercase tracking-wider">
            {property.status}
          </span>
          {property.featured && (
            <span className="bg-gold-400 text-white text-xs font-medium px-3 py-1 uppercase tracking-wider shadow-md">
              Featured
            </span>
          )}
        </div>
        
        {/* Price Tag */}
        <div className="absolute bottom-4 left-4 right-4 flex justify-between items-end translate-y-4 opacity-0 group-hover:translate-y-0 group-hover:opacity-100 transition-all duration-500">
          <p className="text-white font-serif text-2xl font-medium tracking-wide">
            {formatCurrency(property.price)}
          </p>
          <span className="text-white text-sm uppercase tracking-wider border-b border-gold-400 pb-1">
            View Details
          </span>
        </div>
      </Link>

      <div className="p-6">
        <div className="flex items-center gap-2 text-gray-500 text-sm mb-3">
          <MapPin className="w-4 h-4 text-gold-400" />
          <span className="uppercase tracking-wider">{property.location}</span>
        </div>
        
        <Link to={`/properties/${property.id}`}>
          <h3 className="font-serif text-xl font-medium text-luxe-black mb-4 group-hover:text-gold-500 transition-colors line-clamp-1">
            {property.title}
          </h3>
        </Link>

        <div className="flex items-center justify-between pt-4 border-t border-gray-100 text-luxe-black">
          <div className="flex items-center gap-2">
            <Bed className="w-4 h-4 text-gray-400" />
            <span className="text-sm font-medium">{property.beds} Beds</span>
          </div>
          <div className="flex items-center gap-2">
            <Bath className="w-4 h-4 text-gray-400" />
            <span className="text-sm font-medium">{property.baths} Baths</span>
          </div>
          <div className="flex items-center gap-2">
            <Square className="w-4 h-4 text-gray-400" />
            <span className="text-sm font-medium">{property.sqft.toLocaleString()} SqFt</span>
          </div>
        </div>
      </div>
    </motion.div>
  );
}
