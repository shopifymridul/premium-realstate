import { Link } from 'react-router-dom';
import { Facebook, Twitter, Instagram, Linkedin, ArrowRight } from 'lucide-react';

export function Footer() {
  return (
    <footer className="bg-luxe-black text-white pt-24 pb-12">
      <div className="max-w-7xl mx-auto px-6 md:px-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-16 mb-20">
          {/* Brand & Newsletter */}
          <div className="col-span-1 md:col-span-2 lg:col-span-1">
            <Link to="/" className="flex items-center gap-3 mb-8">
              <div className="w-10 h-10 bg-gold-400 flex items-center justify-center">
                <div className="w-4 h-4 border-2 border-white"></div>
              </div>
              <span className="font-serif font-semibold text-2xl tracking-wider uppercase">
                Premier Estates
              </span>
            </Link>
            <p className="text-gray-400 text-sm leading-relaxed mb-8">
              Curating the world's most extraordinary properties for the most discerning clientele.
            </p>
            <form className="flex flex-col gap-4">
              <label htmlFor="newsletter" className="text-sm font-medium uppercase tracking-wider text-gray-300">
                Subscribe to our Newsletter
              </label>
              <div className="relative">
                <input
                  type="email"
                  id="newsletter"
                  placeholder="Enter your email"
                  className="w-full bg-transparent border-b border-gray-600 py-3 pr-10 text-sm focus:outline-none focus:border-gold-400 transition-colors placeholder:text-gray-600"
                />
                <button type="submit" className="absolute right-0 top-1/2 -translate-y-1/2 text-gold-400 hover:text-white transition-colors">
                  <ArrowRight className="w-5 h-5" />
                </button>
              </div>
            </form>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="font-serif text-lg mb-6 uppercase tracking-widest text-gold-400">Properties</h3>
            <ul className="flex flex-col gap-4 text-sm text-gray-400">
              <li><Link to="/buy" className="hover:text-white transition-colors">Buy</Link></li>
              <li><Link to="/sell" className="hover:text-white transition-colors">Sell</Link></li>
              <li><Link to="/rent" className="hover:text-white transition-colors">Rent</Link></li>
              <li><Link to="/properties" className="hover:text-white transition-colors">All Listings</Link></li>
              <li><Link to="/map-search" className="hover:text-white transition-colors">Map Search</Link></li>
            </ul>
          </div>

          {/* Company */}
          <div>
            <h3 className="font-serif text-lg mb-6 uppercase tracking-widest text-gold-400">Company</h3>
            <ul className="flex flex-col gap-4 text-sm text-gray-400">
              <li><Link to="/about" className="hover:text-white transition-colors">About Us</Link></li>
              <li><Link to="/agents" className="hover:text-white transition-colors">Our Agents</Link></li>
              <li><Link to="/blog" className="hover:text-white transition-colors">Journal</Link></li>
              <li><Link to="/contact" className="hover:text-white transition-colors">Contact</Link></li>
              <li><Link to="/faq" className="hover:text-white transition-colors">FAQ</Link></li>
            </ul>
          </div>

          {/* Contact & Social */}
          <div>
            <h3 className="font-serif text-lg mb-6 uppercase tracking-widest text-gold-400">Global Offices</h3>
            <ul className="flex flex-col gap-4 text-sm text-gray-400 mb-8">
              <li>
                <span className="block text-white mb-1">New York</span>
                150 Central Park South, NY 10019
              </li>
              <li>
                <span className="block text-white mb-1">London</span>
                1 Hyde Park, Knightsbridge, SW1X 7LA
              </li>
              <li>
                <span className="block text-white mb-1">Dubai</span>
                Burj Khalifa, Downtown Dubai
              </li>
            </ul>
            <div className="flex items-center gap-4">
              <a href="#" className="w-10 h-10 rounded-full border border-gray-600 flex items-center justify-center hover:border-gold-400 hover:text-gold-400 transition-colors">
                <Instagram className="w-4 h-4" />
              </a>
              <a href="#" className="w-10 h-10 rounded-full border border-gray-600 flex items-center justify-center hover:border-gold-400 hover:text-gold-400 transition-colors">
                <Linkedin className="w-4 h-4" />
              </a>
              <a href="#" className="w-10 h-10 rounded-full border border-gray-600 flex items-center justify-center hover:border-gold-400 hover:text-gold-400 transition-colors">
                <Twitter className="w-4 h-4" />
              </a>
              <a href="#" className="w-10 h-10 rounded-full border border-gray-600 flex items-center justify-center hover:border-gold-400 hover:text-gold-400 transition-colors">
                <Facebook className="w-4 h-4" />
              </a>
            </div>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="border-t border-gray-800 pt-8 flex flex-col md:flex-row items-center justify-between gap-4 text-xs text-gray-500 uppercase tracking-wider">
          <p>&copy; {new Date().getFullYear()} Luxe Estates. All rights reserved.</p>
          <div className="flex items-center gap-6">
            <Link to="/privacy" className="hover:text-white transition-colors">Privacy Policy</Link>
            <Link to="/terms" className="hover:text-white transition-colors">Terms of Service</Link>
          </div>
        </div>
      </div>
    </footer>
  );
}
