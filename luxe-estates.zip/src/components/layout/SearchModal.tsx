import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Search, X, MapPin } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { properties } from '@/data/mockData';

interface SearchModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export function SearchModal({ isOpen, onClose }: SearchModalProps) {
  const [query, setQuery] = useState('');
  const navigate = useNavigate();

  // Filter properties based on query
  const filteredProperties = query.trim() === '' 
    ? [] 
    : properties.filter(p => 
        p.title.toLowerCase().includes(query.toLowerCase()) || 
        p.location.toLowerCase().includes(query.toLowerCase())
      ).slice(0, 4); // Show top 4 results

  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = 'unset';
    }
    return () => {
      document.body.style.overflow = 'unset';
    };
  }, [isOpen]);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (query.trim()) {
      navigate(`/properties?location=${encodeURIComponent(query)}`);
      onClose();
    }
  };

  const handleSelectProperty = (id: string) => {
    navigate(`/properties/${id}`);
    onClose();
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-[100] bg-white/95 backdrop-blur-md flex flex-col"
        >
          <div className="max-w-5xl mx-auto w-full px-6 pt-24 pb-12 flex-grow flex flex-col">
            <button 
              onClick={onClose}
              className="absolute top-8 right-8 p-2 text-gray-500 hover:text-luxe-black transition-colors"
            >
              <X className="w-8 h-8" />
            </button>

            <form onSubmit={handleSearch} className="relative mb-12">
              <Search className="absolute left-0 top-1/2 -translate-y-1/2 w-8 h-8 text-gray-400" />
              <input
                type="text"
                autoFocus
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="Search by location, property name..."
                className="w-full bg-transparent border-b-2 border-gray-200 text-3xl md:text-5xl font-serif py-6 pl-16 pr-4 focus:outline-none focus:border-gold-400 transition-colors placeholder:text-gray-300"
              />
            </form>

            <div className="flex-grow overflow-y-auto">
              {query.trim() !== '' && (
                <div>
                  <h3 className="text-sm font-medium uppercase tracking-widest text-gray-400 mb-6">
                    {filteredProperties.length > 0 ? 'Suggested Properties' : 'No results found'}
                  </h3>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    {filteredProperties.map((property) => (
                      <motion.div
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        key={property.id}
                        onClick={() => handleSelectProperty(property.id)}
                        className="flex gap-4 p-4 rounded-xl hover:bg-gray-50 cursor-pointer transition-colors border border-transparent hover:border-gray-100"
                      >
                        <img 
                          src={property.images[0]} 
                          alt={property.title} 
                          className="w-24 h-24 object-cover rounded-lg shrink-0"
                        />
                        <div className="flex flex-col justify-center">
                          <h4 className="font-serif text-lg text-luxe-black mb-1 line-clamp-1">{property.title}</h4>
                          <div className="flex items-center text-sm text-gray-500 mb-2">
                            <MapPin className="w-3 h-3 mr-1" />
                            {property.location}
                          </div>
                          <span className="text-gold-400 font-medium">${property.price.toLocaleString()}</span>
                        </div>
                      </motion.div>
                    ))}
                  </div>
                </div>
              )}

              {query.trim() === '' && (
                <div className="grid grid-cols-1 md:grid-cols-3 gap-12 mt-12">
                  <div>
                    <h3 className="text-sm font-medium uppercase tracking-widest text-gray-400 mb-6">Popular Locations</h3>
                    <ul className="space-y-4">
                      {['Beverly Hills', 'Manhattan', 'Dubai', 'London', 'Miami'].map(loc => (
                        <li key={loc}>
                          <button 
                            onClick={() => { setQuery(loc); }}
                            className="text-xl font-serif text-gray-600 hover:text-gold-400 transition-colors"
                          >
                            {loc}
                          </button>
                        </li>
                      ))}
                    </ul>
                  </div>
                  <div>
                    <h3 className="text-sm font-medium uppercase tracking-widest text-gray-400 mb-6">Property Types</h3>
                    <ul className="space-y-4">
                      {['Villas', 'Penthouses', 'Mansions', 'Estates'].map(type => (
                        <li key={type}>
                          <button 
                            onClick={() => { navigate(`/properties?type=${type}`); onClose(); }}
                            className="text-xl font-serif text-gray-600 hover:text-gold-400 transition-colors"
                          >
                            {type}
                          </button>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              )}
            </div>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
