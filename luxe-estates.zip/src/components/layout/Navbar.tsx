import { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Menu, X, Search, User } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { cn } from '@/lib/utils';
import { SearchModal } from './SearchModal';

const navLinks = [
  { name: 'Buy', path: '/buy' },
  { name: 'Sell', path: '/sell' },
  { name: 'Rent', path: '/rent' },
  { name: 'Properties', path: '/properties' },
  { name: 'Agents', path: '/agents' },
  { name: 'Blog', path: '/blog' },
  { name: 'Contact', path: '/contact' },
];

export function Navbar() {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const location = useLocation();
  const isHome = location.pathname === '/';

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Close mobile menu on route change
  useEffect(() => {
    setIsMobileMenuOpen(false);
  }, [location.pathname]);

  const navClass = cn(
    'fixed top-0 left-0 right-0 z-50 transition-all duration-300 ease-in-out px-6 md:px-12 py-4',
    isScrolled || !isHome || isMobileMenuOpen
      ? 'bg-white/90 backdrop-blur-md shadow-sm text-luxe-black'
      : 'bg-transparent text-white'
  );

  return (
    <>
      <nav className={navClass}>
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          {/* Logo */}
          <Link to="/" className="flex items-center gap-3 z-50">
            <div className="w-8 h-8 bg-gold-400 flex items-center justify-center">
              <div className="w-3 h-3 border-2 border-white"></div>
            </div>
            <span className="font-serif font-semibold text-xl tracking-wider uppercase">
              Premier Estates
            </span>
          </Link>

          {/* Desktop Nav */}
          <div className="hidden lg:flex items-center gap-8">
            {navLinks.map((link) => (
              <Link
                key={link.name}
                to={link.path}
                className="text-sm font-medium tracking-wide uppercase hover:text-gold-400 transition-colors"
              >
                {link.name}
              </Link>
            ))}
          </div>

          {/* Desktop Actions */}
          <div className="hidden lg:flex items-center gap-6">
            <button 
              onClick={() => setIsSearchOpen(true)}
              className="hover:text-gold-400 transition-colors"
            >
              <Search className="w-5 h-5" />
            </button>
            <Link
              to="/contact"
              className={cn(
                "px-5 py-2 text-sm font-medium uppercase tracking-wider transition-colors border",
                isScrolled || !isHome
                  ? "border-luxe-black hover:bg-luxe-black hover:text-white"
                  : "border-white hover:bg-white hover:text-luxe-black"
              )}
            >
              Valuation
            </Link>
          </div>

          {/* Mobile Menu Toggle */}
          <div className="lg:hidden flex items-center gap-4 z-50">
            <button 
              onClick={() => setIsSearchOpen(true)}
              className="hover:text-gold-400 transition-colors"
            >
              <Search className="w-5 h-5" />
            </button>
            <button
              className="p-2"
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            >
              {isMobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>

        {/* Mobile Menu */}
        <AnimatePresence>
          {isMobileMenuOpen && (
            <motion.div
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="absolute top-full left-0 right-0 bg-white shadow-xl border-t border-gray-100 py-6 px-6 lg:hidden flex flex-col gap-4 text-luxe-black"
            >
              {navLinks.map((link) => (
                <Link
                  key={link.name}
                  to={link.path}
                  className="text-lg font-serif uppercase tracking-wider py-2 border-b border-gray-100"
                >
                  {link.name}
                </Link>
              ))}
            </motion.div>
          )}
        </AnimatePresence>
      </nav>

      <SearchModal 
        isOpen={isSearchOpen} 
        onClose={() => setIsSearchOpen(false)} 
      />
    </>
  );
}
