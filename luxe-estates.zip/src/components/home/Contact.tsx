import React, { useState } from 'react';
import { motion } from 'motion/react';
import { supabase } from '@/lib/supabase';
import { MapPin, Phone, Mail, ArrowRight } from 'lucide-react';
import { Link } from 'react-router-dom';

export function ContactPreview() {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    propertyInterest: '',
    message: ''
  });
  const [status, setStatus] = useState<'idle' | 'submitting' | 'success' | 'error'>('idle');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setStatus('submitting');
    
    try {
      const { error } = await supabase
        .from('contact_submissions')
        .insert([formData]);
        
      if (error) throw error;
      setStatus('success');
      setFormData({ name: '', email: '', phone: '', propertyInterest: '', message: '' });
    } catch (err) {
      console.error('Error submitting form:', err);
      setStatus('error');
    }
  };

  return (
    <section className="py-32 px-6 md:px-12 max-w-7xl mx-auto relative">
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-16">
        <div>
          <motion.span
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-gold-400 font-medium tracking-[0.2em] uppercase text-sm mb-4 block"
          >
            Private Consultation
          </motion.span>
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.1 }}
            className="text-4xl md:text-5xl font-serif text-luxe-black leading-tight mb-8"
          >
            Discuss Your <span className="italic font-light">Vision</span>
          </motion.h2>
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.2 }}
            className="text-gray-600 leading-relaxed mb-12"
          >
            Whether you are looking to acquire a trophy asset or discreetly market your estate, our partners are available for a confidential consultation.
          </motion.p>

          <div className="flex flex-col gap-8">
            <div className="flex items-start gap-4">
              <div className="w-12 h-12 rounded-full bg-luxe-gray flex items-center justify-center shrink-0">
                <MapPin className="w-5 h-5 text-gold-400" />
              </div>
              <div>
                <h4 className="font-serif text-xl text-luxe-black mb-2">Global Headquarters</h4>
                <p className="text-gray-500 text-sm leading-relaxed">150 Central Park South<br />New York, NY 10019<br />United States</p>
              </div>
            </div>
            <div className="flex items-start gap-4">
              <div className="w-12 h-12 rounded-full bg-luxe-gray flex items-center justify-center shrink-0">
                <Phone className="w-5 h-5 text-gold-400" />
              </div>
              <div>
                <h4 className="font-serif text-xl text-luxe-black mb-2">Direct Line</h4>
                <p className="text-gray-500 text-sm leading-relaxed">+1 (212) 555-0199<br />Available 24/7 for clients</p>
              </div>
            </div>
            <div className="flex items-start gap-4">
              <div className="w-12 h-12 rounded-full bg-luxe-gray flex items-center justify-center shrink-0">
                <Mail className="w-5 h-5 text-gold-400" />
              </div>
              <div>
                <h4 className="font-serif text-xl text-luxe-black mb-2">Private Office</h4>
                <p className="text-gray-500 text-sm leading-relaxed">private@luxeestates.com<br />Secure & confidential</p>
              </div>
            </div>
          </div>
        </div>

        <motion.div
          initial={{ opacity: 0, x: 20 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true }}
          transition={{ delay: 0.3 }}
          className="bg-white p-8 md:p-12 shadow-2xl border border-gray-100 relative"
        >
          {/* Decorative corner accents */}
          <div className="absolute top-0 left-0 w-8 h-8 border-t-2 border-l-2 border-gold-400" />
          <div className="absolute top-0 right-0 w-8 h-8 border-t-2 border-r-2 border-gold-400" />
          <div className="absolute bottom-0 left-0 w-8 h-8 border-b-2 border-l-2 border-gold-400" />
          <div className="absolute bottom-0 right-0 w-8 h-8 border-b-2 border-r-2 border-gold-400" />

          <h3 className="font-serif text-2xl text-luxe-black mb-8">Request a Callback</h3>
          
          <form onSubmit={handleSubmit} className="flex flex-col gap-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="flex flex-col gap-2">
                <label className="text-xs uppercase tracking-wider text-gray-500 font-medium">Full Name</label>
                <input
                  type="text"
                  required
                  value={formData.name}
                  onChange={e => setFormData({...formData, name: e.target.value})}
                  className="w-full pb-2 border-b border-gray-200 focus:border-gold-400 focus:outline-none bg-transparent transition-colors"
                />
              </div>
              <div className="flex flex-col gap-2">
                <label className="text-xs uppercase tracking-wider text-gray-500 font-medium">Phone Number</label>
                <input
                  type="tel"
                  required
                  value={formData.phone}
                  onChange={e => setFormData({...formData, phone: e.target.value})}
                  className="w-full pb-2 border-b border-gray-200 focus:border-gold-400 focus:outline-none bg-transparent transition-colors"
                />
              </div>
            </div>
            
            <div className="flex flex-col gap-2">
              <label className="text-xs uppercase tracking-wider text-gray-500 font-medium">Email Address</label>
              <input
                type="email"
                required
                value={formData.email}
                onChange={e => setFormData({...formData, email: e.target.value})}
                className="w-full pb-2 border-b border-gray-200 focus:border-gold-400 focus:outline-none bg-transparent transition-colors"
              />
            </div>

            <div className="flex flex-col gap-2">
              <label className="text-xs uppercase tracking-wider text-gray-500 font-medium">Property Interest (Optional)</label>
              <input
                type="text"
                value={formData.propertyInterest}
                onChange={e => setFormData({...formData, propertyInterest: e.target.value})}
                className="w-full pb-2 border-b border-gray-200 focus:border-gold-400 focus:outline-none bg-transparent transition-colors"
              />
            </div>

            <div className="flex flex-col gap-2">
              <label className="text-xs uppercase tracking-wider text-gray-500 font-medium">Message</label>
              <textarea
                required
                rows={4}
                value={formData.message}
                onChange={e => setFormData({...formData, message: e.target.value})}
                className="w-full pb-2 border-b border-gray-200 focus:border-gold-400 focus:outline-none bg-transparent transition-colors resize-none"
              />
            </div>

            <button
              type="submit"
              disabled={status === 'submitting'}
              className="mt-4 bg-luxe-black text-white py-4 px-8 uppercase tracking-wider text-sm font-medium hover:bg-gold-400 transition-colors flex items-center justify-center gap-2 disabled:opacity-70"
            >
              {status === 'submitting' ? 'Sending...' : 'Send Message'} <ArrowRight className="w-4 h-4" />
            </button>

            {status === 'success' && (
              <p className="text-green-600 text-sm text-center mt-2">Message sent successfully. A partner will contact you shortly.</p>
            )}
            {status === 'error' && (
              <p className="text-red-600 text-sm text-center mt-2">An error occurred. Please try again or contact us directly.</p>
            )}
          </form>
        </motion.div>
      </div>
    </section>
  );
}

export function MapPreview() {
  return (
    <section className="h-[60vh] relative bg-luxe-gray flex items-center justify-center overflow-hidden">
      <div className="absolute inset-0 z-0 opacity-50 grayscale">
        <img
          src="https://images.unsplash.com/photo-1524661135-423995f22d0b?auto=format&fit=crop&q=80&w=2000"
          alt="Map Background"
          className="w-full h-full object-cover"
          loading="lazy"
          referrerPolicy="no-referrer"
        />
      </div>
      <div className="relative z-10 glass p-12 text-center max-w-lg mx-auto shadow-2xl">
        <MapPin className="w-12 h-12 text-gold-400 mx-auto mb-6" />
        <h2 className="text-3xl font-serif text-luxe-black mb-4">Global Portfolio Map</h2>
        <p className="text-gray-600 mb-8">Explore our exclusive listings across the world's most prestigious locations.</p>
        <Link to="/map-search" className="bg-luxe-black text-white py-3 px-8 uppercase tracking-wider text-sm font-medium hover:bg-gold-400 transition-colors inline-flex items-center gap-2">
          Open Interactive Map <ArrowRight className="w-4 h-4" />
        </Link>
      </div>
    </section>
  );
}
