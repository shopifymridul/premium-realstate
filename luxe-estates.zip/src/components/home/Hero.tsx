import { useState } from 'react';
import { motion } from 'motion/react';
import { ArrowRight, Search, MapPin, Home, DollarSign } from 'lucide-react';
import { useNavigate, Link } from 'react-router-dom';

export function Hero() {
  return (
    <section className="relative h-[100svh] min-h-[800px] flex items-center justify-center overflow-hidden">
      {/* Video Background */}
      <div className="absolute inset-0 z-0">
        <video
          autoPlay
          loop
          muted
          playsInline
          className="w-full h-full object-cover"
          poster="https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?auto=format&fit=crop&q=80&w=2000"
        >
          <source src="https://player.vimeo.com/external/494252666.sd.mp4?s=2f448b4461a29332211910654198136321454023&profile_id=164&oauth2_token_id=57447761" type="video/mp4" />
        </video>
        <div className="absolute inset-0 bg-black/40" />
      </div>

      <div className="relative z-10 text-center px-6 max-w-5xl mx-auto mt-12 md:mt-0">
        <motion.span
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="text-gold-400 font-medium tracking-[0.2em] uppercase text-sm md:text-base mb-6 block"
        >
          Extraordinary Living
        </motion.span>
        <motion.h1
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.2 }}
          className="text-5xl md:text-7xl lg:text-8xl font-serif text-white mb-8 leading-tight"
        >
          Discover Your <br />
          <span className="italic font-light">Perfect</span> Sanctuary
        </motion.h1>
        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.4 }}
          className="text-lg md:text-xl text-gray-200 mb-12 max-w-2xl mx-auto font-light"
        >
          Curating the world's most extraordinary properties for the most discerning clientele.
        </motion.p>
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.6 }}
          className="flex flex-col sm:flex-row items-center justify-center gap-6"
        >
          <Link to="/properties" className="bg-gold-400 text-white px-8 py-4 uppercase tracking-wider text-sm font-medium hover:bg-gold-500 transition-colors w-full sm:w-auto inline-block">
            Explore Properties
          </Link>
          <Link to="/contact" className="bg-transparent border border-white text-white px-8 py-4 uppercase tracking-wider text-sm font-medium hover:bg-white hover:text-luxe-black transition-colors w-full sm:w-auto flex items-center justify-center gap-2">
            Contact an Agent <ArrowRight className="w-4 h-4" />
          </Link>
        </motion.div>
      </div>

      {/* Scroll Indicator */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1.5, duration: 1 }}
        className="hidden md:flex absolute bottom-8 left-1/2 -translate-x-1/2 flex-col items-center gap-2 text-white/70"
      >
        <span className="text-xs uppercase tracking-widest">Scroll</span>
        <div className="w-[1px] h-12 bg-white/30 relative overflow-hidden">
          <motion.div
            animate={{ y: [0, 48] }}
            transition={{ repeat: Infinity, duration: 1.5, ease: "linear" }}
            className="absolute top-0 left-0 w-full h-1/2 bg-white"
          />
        </div>
      </motion.div>
    </section>
  );
}

export function AdvancedSearch() {
  const navigate = useNavigate();
  const [location, setLocation] = useState('');
  const [type, setType] = useState('All Types');
  const [price, setPrice] = useState('Any Price');

  const handleSearch = () => {
    navigate(`/properties?location=${encodeURIComponent(location)}&type=${encodeURIComponent(type)}&price=${encodeURIComponent(price)}`);
  };

  return (
    <section className="relative -mt-16 md:-mt-24 z-20 max-w-6xl mx-auto px-6 mb-16">
      <div className="glass p-8 shadow-2xl">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          <div className="flex flex-col gap-2">
            <label className="text-xs uppercase tracking-wider text-gray-500 font-medium">Location</label>
            <div className="relative">
              <MapPin className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
              <input 
                type="text" 
                value={location}
                onChange={(e) => setLocation(e.target.value)}
                placeholder="City, Neighborhood, or ZIP" 
                className="w-full pl-10 pr-4 py-3 border-b border-gray-200 focus:border-gold-400 focus:outline-none bg-transparent transition-colors" 
              />
            </div>
          </div>
          <div className="flex flex-col gap-2">
            <label className="text-xs uppercase tracking-wider text-gray-500 font-medium">Property Type</label>
            <div className="relative">
              <Home className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
              <select 
                value={type}
                onChange={(e) => setType(e.target.value)}
                className="w-full pl-10 pr-4 py-3 border-b border-gray-200 focus:border-gold-400 focus:outline-none bg-transparent appearance-none transition-colors"
              >
                <option>All Types</option>
                <option>Villa</option>
                <option>Penthouse</option>
                <option>Mansion</option>
                <option>Apartment</option>
              </select>
            </div>
          </div>
          <div className="flex flex-col gap-2">
            <label className="text-xs uppercase tracking-wider text-gray-500 font-medium">Price Range</label>
            <div className="relative">
              <DollarSign className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
              <select 
                value={price}
                onChange={(e) => setPrice(e.target.value)}
                className="w-full pl-10 pr-4 py-3 border-b border-gray-200 focus:border-gold-400 focus:outline-none bg-transparent appearance-none transition-colors"
              >
                <option>Any Price</option>
                <option>$1M - $5M</option>
                <option>$5M - $10M</option>
                <option>$10M - $20M</option>
                <option>$20M+</option>
              </select>
            </div>
          </div>
          <div className="flex items-end">
            <button 
              onClick={handleSearch}
              className="w-full bg-luxe-black text-white py-3 px-6 uppercase tracking-wider text-sm font-medium hover:bg-gold-400 transition-colors flex items-center justify-center gap-2"
            >
              <Search className="w-4 h-4" /> Search
            </button>
          </div>
        </div>
      </div>
    </section>
  );
}
