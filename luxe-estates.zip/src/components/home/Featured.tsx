import { motion } from 'motion/react';
import { PropertyCard } from '@/components/ui/PropertyCard';
import { properties } from '@/data/mockData';
import { ArrowRight } from 'lucide-react';
import { Link } from 'react-router-dom';

export function FeaturedProperties() {
  const featured = properties.slice(0, 12);

  return (
    <section className="py-32 px-6 md:px-12 max-w-7xl mx-auto bg-luxe-gray/50 rounded-3xl my-12">
      <div className="flex flex-col md:flex-row justify-between items-end mb-16 gap-8">
        <div className="max-w-2xl">
          <motion.span
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-gold-400 font-medium tracking-[0.2em] uppercase text-sm mb-4 block"
          >
            Exclusive Collection
          </motion.span>
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.1 }}
            className="text-4xl md:text-5xl font-serif text-luxe-black leading-tight"
          >
            Featured Luxury <span className="italic font-light">Properties</span>
          </motion.h2>
        </div>
        <motion.div
          initial={{ opacity: 0, x: 20 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true }}
          transition={{ delay: 0.2 }}
        >
          <Link to="/properties" className="flex items-center gap-2 text-sm font-medium uppercase tracking-wider hover:text-gold-400 transition-colors border-b border-luxe-black pb-1 hover:border-gold-400">
            View All Properties <ArrowRight className="w-4 h-4" />
          </Link>
        </motion.div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {featured.map((property, index) => (
          <PropertyCard key={property.id} property={property} index={index} />
        ))}
      </div>
    </section>
  );
}

const categories = [
  { name: 'Villas', count: 45, image: 'https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?auto=format&fit=crop&q=80&w=800' },
  { name: 'Penthouses', count: 28, image: 'https://images.unsplash.com/photo-1512917774080-9991f1c4c750?auto=format&fit=crop&q=80&w=800' },
  { name: 'Mansions', count: 12, image: 'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&q=80&w=800' },
  { name: 'Apartments', count: 86, image: 'https://images.unsplash.com/photo-1494526585095-c41746248156?auto=format&fit=crop&q=80&w=800' },
];

export function Categories() {
  return (
    <section className="py-24 bg-luxe-black text-white">
      <div className="max-w-7xl mx-auto px-6 md:px-12">
        <div className="text-center mb-16">
          <span className="text-gold-400 font-medium tracking-[0.2em] uppercase text-sm mb-4 block">
            Curated Lifestyles
          </span>
          <h2 className="text-4xl md:text-5xl font-serif leading-tight">
            Explore by <span className="italic font-light">Category</span>
          </h2>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {categories.map((category, index) => (
            <Link to={`/properties?category=${category.name}`} key={category.name}>
              <motion.div
                initial={{ opacity: 0, scale: 0.95 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                className="group relative aspect-[3/4] overflow-hidden cursor-pointer h-full block"
              >
                <img
                  src={category.image}
                  alt={category.name}
                  className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110 opacity-60 group-hover:opacity-80"
                  loading="lazy"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent" />
                <div className="absolute bottom-8 left-8">
                  <h3 className="text-2xl font-serif mb-2">{category.name}</h3>
                  <p className="text-sm text-gray-300 uppercase tracking-wider">{category.count} Properties</p>
                </div>
                <div className="absolute top-8 right-8 w-10 h-10 rounded-full border border-white/30 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-all duration-300 translate-x-4 group-hover:translate-x-0 bg-white/10 backdrop-blur-sm">
                  <ArrowRight className="w-4 h-4" />
                </div>
              </motion.div>
            </Link>
          ))}
        </div>
      </div>
    </section>
  );
}
