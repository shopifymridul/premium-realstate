import { motion } from 'motion/react';
import { Shield, Award, Globe, Key } from 'lucide-react';
import { useState, useEffect, useRef } from 'react';

const features = [
  {
    icon: <Globe className="w-8 h-8 text-gold-400" />,
    title: 'Global Reach',
    description: 'Access to an exclusive network of international buyers and off-market properties worldwide.'
  },
  {
    icon: <Shield className="w-8 h-8 text-gold-400" />,
    title: 'Absolute Discretion',
    description: 'Uncompromising privacy and confidentiality for high-net-worth individuals and public figures.'
  },
  {
    icon: <Award className="w-8 h-8 text-gold-400" />,
    title: 'Award-Winning Service',
    description: 'Recognized globally for excellence in luxury real estate marketing and client satisfaction.'
  },
  {
    icon: <Key className="w-8 h-8 text-gold-400" />,
    title: 'Turnkey Solutions',
    description: 'Comprehensive concierge services from acquisition to interior design and estate management.'
  }
];

export function WhyChooseUs() {
  return (
    <section className="py-32 px-6 md:px-12 max-w-7xl mx-auto">
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
        <div>
          <motion.span
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-gold-400 font-medium tracking-[0.2em] uppercase text-sm mb-4 block"
          >
            The Luxe Advantage
          </motion.span>
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.1 }}
            className="text-4xl md:text-5xl font-serif text-luxe-black leading-tight mb-8"
          >
            Redefining <span className="italic font-light">Luxury</span> Real Estate
          </motion.h2>
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.2 }}
            className="text-gray-600 leading-relaxed mb-12"
          >
            For over two decades, Luxe Estates has been the trusted advisor to the world's most discerning buyers and sellers. We don't just sell properties; we curate lifestyles and build generational wealth through strategic real estate acquisitions.
          </motion.p>
          
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-8">
            {features.map((feature, index) => (
              <motion.div
                key={feature.title}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: 0.3 + index * 0.1 }}
                className="flex flex-col gap-4"
              >
                <div className="w-16 h-16 rounded-full bg-gold-400/10 flex items-center justify-center">
                  {feature.icon}
                </div>
                <h3 className="font-serif text-xl text-luxe-black">{feature.title}</h3>
                <p className="text-sm text-gray-500 leading-relaxed">{feature.description}</p>
              </motion.div>
            ))}
          </div>
        </div>
        
        <div className="relative">
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="aspect-[4/5] overflow-hidden rounded-sm"
          >
            <img
              src="https://images.unsplash.com/photo-1600210492486-724fe5c67fb0?auto=format&fit=crop&q=80&w=1200"
              alt="Luxury Interior"
              className="w-full h-full object-cover"
              loading="lazy"
              referrerPolicy="no-referrer"
            />
          </motion.div>
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8, delay: 0.4 }}
            className="absolute -bottom-10 -left-10 bg-white p-8 shadow-2xl max-w-xs hidden md:block"
          >
            <p className="font-serif text-2xl text-luxe-black mb-2">"The epitome of professional excellence."</p>
            <p className="text-sm text-gray-500 uppercase tracking-wider">— Forbes Real Estate</p>
          </motion.div>
        </div>
      </div>
    </section>
  );
}

function Counter({ end, suffix = '', duration = 2000 }: { end: number, suffix?: string, duration?: number }) {
  const [count, setCount] = useState(0);
  const countRef = useRef(null);
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
        }
      },
      { threshold: 0.1 }
    );

    if (countRef.current) {
      observer.observe(countRef.current);
    }

    return () => observer.disconnect();
  }, []);

  useEffect(() => {
    if (!isVisible) return;

    let startTime: number | null = null;
    const animate = (currentTime: number) => {
      if (!startTime) startTime = currentTime;
      const progress = Math.min((currentTime - startTime) / duration, 1);
      
      // Easing function (easeOutExpo)
      const easeOut = progress === 1 ? 1 : 1 - Math.pow(2, -10 * progress);
      
      setCount(Math.floor(easeOut * end));
      
      if (progress < 1) {
        requestAnimationFrame(animate);
      }
    };

    requestAnimationFrame(animate);
  }, [end, duration, isVisible]);

  return (
    <span ref={countRef} className="text-5xl md:text-6xl font-serif text-gold-400">
      {count}{suffix}
    </span>
  );
}

export function Stats() {
  return (
    <section className="py-24 bg-luxe-gray border-y border-gray-200">
      <div className="max-w-7xl mx-auto px-6 md:px-12">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-12 text-center">
          <div className="flex flex-col gap-4">
            <Counter end={15} suffix="B+" />
            <span className="text-sm uppercase tracking-widest text-gray-600 font-medium">Sales Volume</span>
          </div>
          <div className="flex flex-col gap-4">
            <Counter end={25} suffix="+" />
            <span className="text-sm uppercase tracking-widest text-gray-600 font-medium">Global Offices</span>
          </div>
          <div className="flex flex-col gap-4">
            <Counter end={98} suffix="%" />
            <span className="text-sm uppercase tracking-widest text-gray-600 font-medium">Client Retention</span>
          </div>
          <div className="flex flex-col gap-4">
            <Counter end={1200} suffix="+" />
            <span className="text-sm uppercase tracking-widest text-gray-600 font-medium">Properties Sold</span>
          </div>
        </div>
      </div>
    </section>
  );
}
