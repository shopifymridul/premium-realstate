export const articles = [
  {
    id: 1,
    title: "The Rise of Branded Residences",
    category: "Market Trends",
    date: "October 12, 2023",
    image: "https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?auto=format&fit=crop&q=80&w=800",
    excerpt: "Why luxury buyers are increasingly drawn to properties managed by world-renowned hospitality brands. These residences offer unparalleled amenities and a seamless lifestyle."
  },
  {
    id: 2,
    title: "Designing for Wellness",
    category: "Architecture",
    date: "September 28, 2023",
    image: "https://images.unsplash.com/photo-1512917774080-9991f1c4c750?auto=format&fit=crop&q=80&w=800",
    excerpt: "How modern luxury homes are incorporating health and wellness features into their core design, from advanced air purification systems to dedicated meditation spaces."
  },
  {
    id: 3,
    title: "Investing in Emerging Markets",
    category: "Investment",
    date: "September 15, 2023",
    image: "https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?auto=format&fit=crop&q=80&w=800",
    excerpt: "A look at the most promising global real estate markets for high-net-worth investors looking to diversify their portfolios with high-yield opportunities."
  },
  {
    id: 4,
    title: "The Future of Smart Homes",
    category: "Technology",
    date: "August 30, 2023",
    image: "https://images.unsplash.com/photo-1558036117-15d82a90b9b1?auto=format&fit=crop&q=80&w=800",
    excerpt: "Exploring the latest technological advancements in home automation, security, and energy efficiency that are becoming standard in luxury properties."
  },
  {
    id: 5,
    title: "Sustainable Luxury Architecture",
    category: "Architecture",
    date: "August 12, 2023",
    image: "https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&q=80&w=800",
    excerpt: "How architects are blending eco-friendly materials and sustainable practices with high-end design to create stunning, environmentally conscious homes."
  },
  {
    id: 6,
    title: "Navigating the European Market",
    category: "Market Trends",
    date: "July 22, 2023",
    image: "https://images.unsplash.com/photo-1464146072230-91cabc968266?auto=format&fit=crop&q=80&w=800",
    excerpt: "An in-depth guide to purchasing historic estates and modern villas across Europe's most coveted destinations, from the French Riviera to the Swiss Alps."
  },
  {
    id: 7,
    title: "The Art of Home Staging",
    category: "Interior Design",
    date: "July 05, 2023",
    image: "https://images.unsplash.com/photo-1600607686527-6fb886090705?auto=format&fit=crop&q=80&w=800",
    excerpt: "Expert tips on how to prepare your luxury property for the market to maximize its appeal and secure the highest possible sale price."
  },
  {
    id: 8,
    title: "Private Islands: The Ultimate Luxury",
    category: "Lifestyle",
    date: "June 18, 2023",
    image: "https://images.unsplash.com/photo-1559128010-7c1ad6e1b6a5?auto=format&fit=crop&q=80&w=800",
    excerpt: "Discover what it takes to purchase, develop, and maintain a private island retreat in some of the world's most pristine tropical locations."
  },
  {
    id: 9,
    title: "Collecting Art for Your Home",
    category: "Lifestyle",
    date: "June 02, 2023",
    image: "https://images.unsplash.com/photo-1513694203232-719a280e022f?auto=format&fit=crop&q=80&w=800",
    excerpt: "A guide to curating a museum-quality art collection that complements your home's architecture and interior design."
  },
  {
    id: 10,
    title: "Understanding Real Estate Taxes",
    category: "Investment",
    date: "May 15, 2023",
    image: "https://images.unsplash.com/photo-1454165804606-c3d57bc86b40?auto=format&fit=crop&q=80&w=800",
    excerpt: "Essential tax considerations for high-net-worth individuals investing in international real estate markets and luxury properties."
  }
];
