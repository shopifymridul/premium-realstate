export interface Property {
  id: string;
  title: string;
  location: string;
  price: number;
  beds: number;
  baths: number;
  sqft: number;
  images: string[];
  agent: {
    name: string;
    phone: string;
    image: string;
  };
  description: string;
  category: 'Villa' | 'Penthouse' | 'Mansion' | 'Apartment';
  status: 'For Sale' | 'For Rent' | 'Sold';
  featured: boolean;
}

export const properties: Property[] = [
  {
    id: '1',
    title: 'The Beverly Hills Estate',
    location: 'Beverly Hills, CA, USA',
    price: 45000000,
    beds: 8,
    baths: 12,
    sqft: 25000,
    images: [
      'https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?auto=format&fit=crop&q=80&w=2000',
      'https://images.unsplash.com/photo-1512917774080-9991f1c4c750?auto=format&fit=crop&q=80&w=2000',
      'https://images.unsplash.com/photo-1600607687931-ceeb66d11262?auto=format&fit=crop&q=80&w=2000'
    ],
    agent: {
      name: 'Sarah Jenkins',
      phone: '+1 (310) 555-0198',
      image: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&q=80&w=800'
    },
    description: 'A masterpiece of modern architecture, this estate offers unparalleled luxury and panoramic views of Los Angeles. Features include a 20-car gallery, private theater, and a zero-edge infinity pool.',
    category: 'Mansion',
    status: 'For Sale',
    featured: true
  },
  {
    id: '2',
    title: 'Palm Jumeirah Signature Villa',
    location: 'Palm Jumeirah, Dubai, UAE',
    price: 28500000,
    beds: 6,
    baths: 8,
    sqft: 14000,
    images: [
      'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&q=80&w=2000',
      'https://images.unsplash.com/photo-1600566753190-17f0baa2a6c3?auto=format&fit=crop&q=80&w=2000'
    ],
    agent: {
      name: 'Omar Al-Fayed',
      phone: '+971 50 555 0192',
      image: 'https://images.unsplash.com/photo-1560250097-0b93528c311a?auto=format&fit=crop&q=80&w=800'
    },
    description: 'Experience waterfront living at its finest. This custom-built signature villa on the Fronds of Palm Jumeirah boasts private beach access, a temperature-controlled pool, and bespoke Italian furnishings.',
    category: 'Villa',
    status: 'For Sale',
    featured: true
  },
  {
    id: '3',
    title: 'One Hyde Park Penthouse',
    location: 'Knightsbridge, London, UK',
    price: 85000000,
    beds: 5,
    baths: 6,
    sqft: 18000,
    images: [
      'https://images.unsplash.com/photo-1512917774080-9991f1c4c750?auto=format&fit=crop&q=80&w=2000',
      'https://images.unsplash.com/photo-1600607686527-6fb886090705?auto=format&fit=crop&q=80&w=2000'
    ],
    agent: {
      name: 'Eleanor Vance',
      phone: '+44 20 7946 0123',
      image: 'https://images.unsplash.com/photo-1580489944761-15a19d654956?auto=format&fit=crop&q=80&w=800'
    },
    description: 'The crown jewel of London real estate. This duplex penthouse offers sweeping views of Hyde Park, 24/7 Mandarin Oriental hotel service, bulletproof glass, and a private wine cellar.',
    category: 'Penthouse',
    status: 'For Sale',
    featured: true
  },
  {
    id: '4',
    title: 'Malibu Oceanfront Retreat',
    location: 'Malibu, CA, USA',
    price: 32000000,
    beds: 5,
    baths: 7,
    sqft: 8500,
    images: [
      'https://images.unsplash.com/photo-1494526585095-c41746248156?auto=format&fit=crop&q=80&w=2000',
      'https://images.unsplash.com/photo-1600566752355-35792bedcfea?auto=format&fit=crop&q=80&w=2000'
    ],
    agent: {
      name: 'Sarah Jenkins',
      phone: '+1 (310) 555-0198',
      image: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&q=80&w=800'
    },
    description: 'Direct beach access and unobstructed ocean views define this architectural triumph. Features a massive deck, outdoor kitchen, and a master suite that feels like floating on water.',
    category: 'Villa',
    status: 'For Sale',
    featured: false
  },
  {
    id: '5',
    title: 'Downtown Manhattan Triplex',
    location: 'New York, NY, USA',
    price: 22500000,
    beds: 4,
    baths: 5,
    sqft: 6200,
    images: [
      'https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?auto=format&fit=crop&q=80&w=2000',
      'https://images.unsplash.com/photo-1600607687931-ceeb66d11262?auto=format&fit=crop&q=80&w=2000'
    ],
    agent: {
      name: 'Michael Chen',
      phone: '+1 (212) 555-0891',
      image: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?auto=format&fit=crop&q=80&w=800'
    },
    description: 'A rare triplex penthouse in the heart of Tribeca. Boasts a private rooftop terrace, double-height ceilings, and custom millwork throughout.',
    category: 'Penthouse',
    status: 'For Sale',
    featured: true
  },
  {
    id: '6',
    title: 'Emirates Hills Golf Estate',
    location: 'Emirates Hills, Dubai, UAE',
    price: 41000000,
    beds: 7,
    baths: 9,
    sqft: 22000,
    images: [
      'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&q=80&w=2000',
      'https://images.unsplash.com/photo-1600566753190-17f0baa2a6c3?auto=format&fit=crop&q=80&w=2000'
    ],
    agent: {
      name: 'Omar Al-Fayed',
      phone: '+971 50 555 0192',
      image: 'https://images.unsplash.com/photo-1560250097-0b93528c311a?auto=format&fit=crop&q=80&w=800'
    },
    description: 'Overlooking the Montgomerie Golf Course, this palatial estate features a grand double staircase, indoor pool, spa, and a 12-seat cinema.',
    category: 'Mansion',
    status: 'For Sale',
    featured: false
  },
  {
    id: '7',
    title: 'Mayfair Townhouse',
    location: 'Mayfair, London, UK',
    price: 18000000,
    beds: 5,
    baths: 5,
    sqft: 5500,
    images: [
      'https://images.unsplash.com/photo-1512917774080-9991f1c4c750?auto=format&fit=crop&q=80&w=2000',
      'https://images.unsplash.com/photo-1600607686527-6fb886090705?auto=format&fit=crop&q=80&w=2000'
    ],
    agent: {
      name: 'Eleanor Vance',
      phone: '+44 20 7946 0123',
      image: 'https://images.unsplash.com/photo-1580489944761-15a19d654956?auto=format&fit=crop&q=80&w=800'
    },
    description: 'A meticulously restored Grade II listed townhouse. Combines historic charm with modern luxury, featuring a private garden and mews house.',
    category: 'Villa',
    status: 'For Sale',
    featured: false
  },
  {
    id: '8',
    title: 'Miami Beach Modern',
    location: 'Miami Beach, FL, USA',
    price: 29500000,
    beds: 6,
    baths: 7,
    sqft: 11000,
    images: [
      'https://images.unsplash.com/photo-1494526585095-c41746248156?auto=format&fit=crop&q=80&w=2000',
      'https://images.unsplash.com/photo-1600566752355-35792bedcfea?auto=format&fit=crop&q=80&w=2000'
    ],
    agent: {
      name: 'Michael Chen',
      phone: '+1 (212) 555-0891',
      image: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?auto=format&fit=crop&q=80&w=800'
    },
    description: 'Ultra-modern waterfront masterpiece with a private dock, rooftop lounge, and seamless indoor-outdoor living spaces.',
    category: 'Villa',
    status: 'For Sale',
    featured: true
  },
  {
    id: '9',
    title: 'Aspen Mountain Lodge',
    location: 'Aspen, CO, USA',
    price: 35000000,
    beds: 7,
    baths: 9,
    sqft: 15000,
    images: [
      'https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?auto=format&fit=crop&q=80&w=2000',
      'https://images.unsplash.com/photo-1600607687931-ceeb66d11262?auto=format&fit=crop&q=80&w=2000'
    ],
    agent: {
      name: 'Sarah Jenkins',
      phone: '+1 (310) 555-0198',
      image: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&q=80&w=800'
    },
    description: 'Ski-in/ski-out luxury lodge with breathtaking mountain views, a massive stone fireplace, indoor heated pool, and wine tasting room.',
    category: 'Mansion',
    status: 'For Sale',
    featured: false
  },
  {
    id: '10',
    title: 'Burj Khalifa Sky Suite',
    location: 'Downtown Dubai, UAE',
    price: 15000000,
    beds: 3,
    baths: 4,
    sqft: 4500,
    images: [
      'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&q=80&w=2000',
      'https://images.unsplash.com/photo-1600566753190-17f0baa2a6c3?auto=format&fit=crop&q=80&w=2000'
    ],
    agent: {
      name: 'Omar Al-Fayed',
      phone: '+971 50 555 0192',
      image: 'https://images.unsplash.com/photo-1560250097-0b93528c311a?auto=format&fit=crop&q=80&w=800'
    },
    description: 'Live above the clouds in the world\'s tallest building. This fully furnished suite offers 360-degree views of the city and Arabian Gulf.',
    category: 'Apartment',
    status: 'For Sale',
    featured: false
  },
  {
    id: '11',
    title: 'Bel Air Promontory',
    location: 'Bel Air, CA, USA',
    price: 65000000,
    beds: 9,
    baths: 14,
    sqft: 30000,
    images: [
      'https://images.unsplash.com/photo-1512917774080-9991f1c4c750?auto=format&fit=crop&q=80&w=2000',
      'https://images.unsplash.com/photo-1600607686527-6fb886090705?auto=format&fit=crop&q=80&w=2000'
    ],
    agent: {
      name: 'Sarah Jenkins',
      phone: '+1 (310) 555-0198',
      image: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&q=80&w=800'
    },
    description: 'A modern fortress of glass and steel perched on a promontory. Features a 150-foot infinity pool, wellness center, and a nightclub.',
    category: 'Mansion',
    status: 'For Sale',
    featured: true
  },
  {
    id: '12',
    title: 'Chelsea Riverside Apartment',
    location: 'Chelsea, London, UK',
    price: 12000000,
    beds: 3,
    baths: 3,
    sqft: 2800,
    images: [
      'https://images.unsplash.com/photo-1494526585095-c41746248156?auto=format&fit=crop&q=80&w=2000',
      'https://images.unsplash.com/photo-1600566752355-35792bedcfea?auto=format&fit=crop&q=80&w=2000'
    ],
    agent: {
      name: 'Eleanor Vance',
      phone: '+44 20 7946 0123',
      image: 'https://images.unsplash.com/photo-1580489944761-15a19d654956?auto=format&fit=crop&q=80&w=800'
    },
    description: 'Stunning lateral apartment with direct views over the River Thames. Includes 24-hour concierge and secure underground parking.',
    category: 'Apartment',
    status: 'For Sale',
    featured: false
  },
  {
    id: '13',
    title: 'Hamptons Summer Estate',
    location: 'Southampton, NY, USA',
    price: 48000000,
    beds: 10,
    baths: 12,
    sqft: 18000,
    images: [
      'https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?auto=format&fit=crop&q=80&w=2000',
      'https://images.unsplash.com/photo-1600607687931-ceeb66d11262?auto=format&fit=crop&q=80&w=2000'
    ],
    agent: {
      name: 'Michael Chen',
      phone: '+1 (212) 555-0891',
      image: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?auto=format&fit=crop&q=80&w=800'
    },
    description: 'Classic shingle-style estate on 5 acres. Features a sunken tennis court, pool house, formal gardens, and private beach access.',
    category: 'Mansion',
    status: 'For Sale',
    featured: false
  },
  {
    id: '14',
    title: 'Dubai Marina Penthouse',
    location: 'Dubai Marina, UAE',
    price: 18500000,
    beds: 4,
    baths: 5,
    sqft: 7000,
    images: [
      'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&q=80&w=2000',
      'https://images.unsplash.com/photo-1600566753190-17f0baa2a6c3?auto=format&fit=crop&q=80&w=2000'
    ],
    agent: {
      name: 'Omar Al-Fayed',
      phone: '+971 50 555 0192',
      image: 'https://images.unsplash.com/photo-1560250097-0b93528c311a?auto=format&fit=crop&q=80&w=800'
    },
    description: 'Full-floor penthouse with panoramic views of the marina and sea. Features a private pool on the terrace and smart home automation.',
    category: 'Penthouse',
    status: 'For Sale',
    featured: false
  },
  {
    id: '15',
    title: 'Kensington Palace Gardens',
    location: 'Kensington, London, UK',
    price: 120000000,
    beds: 12,
    baths: 15,
    sqft: 35000,
    images: [
      'https://images.unsplash.com/photo-1512917774080-9991f1c4c750?auto=format&fit=crop&q=80&w=2000',
      'https://images.unsplash.com/photo-1600607686527-6fb886090705?auto=format&fit=crop&q=80&w=2000'
    ],
    agent: {
      name: 'Eleanor Vance',
      phone: '+44 20 7946 0123',
      image: 'https://images.unsplash.com/photo-1580489944761-15a19d654956?auto=format&fit=crop&q=80&w=800'
    },
    description: 'Located on the most exclusive street in London. This historic mansion features a subterranean leisure complex, ballroom, and staff quarters.',
    category: 'Mansion',
    status: 'For Sale',
    featured: true
  },
  {
    id: '16',
    title: 'Lake Como Villa',
    location: 'Lake Como, Italy',
    price: 38000000,
    beds: 8,
    baths: 9,
    sqft: 12000,
    images: [
      'https://images.unsplash.com/photo-1494526585095-c41746248156?auto=format&fit=crop&q=80&w=2000',
      'https://images.unsplash.com/photo-1600566752355-35792bedcfea?auto=format&fit=crop&q=80&w=2000'
    ],
    agent: {
      name: 'Michael Chen',
      phone: '+1 (212) 555-0891',
      image: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?auto=format&fit=crop&q=80&w=800'
    },
    description: 'Historic 19th-century villa with direct lake access, a private boat house, frescoed ceilings, and manicured Italian gardens.',
    category: 'Villa',
    status: 'For Sale',
    featured: false
  },
  {
    id: '17',
    title: 'Monaco Harbor View',
    location: 'Monte Carlo, Monaco',
    price: 55000000,
    beds: 4,
    baths: 5,
    sqft: 5000,
    images: [
      'https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?auto=format&fit=crop&q=80&w=2000',
      'https://images.unsplash.com/photo-1600607687931-ceeb66d11262?auto=format&fit=crop&q=80&w=2000'
    ],
    agent: {
      name: 'Eleanor Vance',
      phone: '+44 20 7946 0123',
      image: 'https://images.unsplash.com/photo-1580489944761-15a19d654956?auto=format&fit=crop&q=80&w=800'
    },
    description: 'Overlooking Port Hercules, this ultra-luxury apartment offers front-row seats to the Monaco Grand Prix and features bespoke finishes.',
    category: 'Apartment',
    status: 'For Sale',
    featured: false
  },
  {
    id: '18',
    title: 'Atherton Tech Estate',
    location: 'Atherton, CA, USA',
    price: 42000000,
    beds: 6,
    baths: 8,
    sqft: 16000,
    images: [
      'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&q=80&w=2000',
      'https://images.unsplash.com/photo-1600566753190-17f0baa2a6c3?auto=format&fit=crop&q=80&w=2000'
    ],
    agent: {
      name: 'Sarah Jenkins',
      phone: '+1 (310) 555-0198',
      image: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&q=80&w=800'
    },
    description: 'Located in the most expensive zip code in America. Features state-of-the-art security, a subterranean garage, and a detached guest house.',
    category: 'Mansion',
    status: 'For Sale',
    featured: false
  },
  {
    id: '19',
    title: 'Parisian Haussmann Apartment',
    location: '8th Arrondissement, Paris, France',
    price: 24000000,
    beds: 4,
    baths: 4,
    sqft: 4500,
    images: [
      'https://images.unsplash.com/photo-1512917774080-9991f1c4c750?auto=format&fit=crop&q=80&w=2000',
      'https://images.unsplash.com/photo-1600607686527-6fb886090705?auto=format&fit=crop&q=80&w=2000'
    ],
    agent: {
      name: 'Michael Chen',
      phone: '+1 (212) 555-0891',
      image: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?auto=format&fit=crop&q=80&w=800'
    },
    description: 'Classic Parisian elegance with views of the Eiffel Tower. Features original moldings, herringbone parquet floors, and marble fireplaces.',
    category: 'Apartment',
    status: 'For Sale',
    featured: false
  },
  {
    id: '20',
    title: 'St. Barts Cliffside Villa',
    location: 'St. Barts, Caribbean',
    price: 31000000,
    beds: 5,
    baths: 6,
    sqft: 8000,
    images: [
      'https://images.unsplash.com/photo-1494526585095-c41746248156?auto=format&fit=crop&q=80&w=2000',
      'https://images.unsplash.com/photo-1600566752355-35792bedcfea?auto=format&fit=crop&q=80&w=2000'
    ],
    agent: {
      name: 'Sarah Jenkins',
      phone: '+1 (310) 555-0198',
      image: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&q=80&w=800'
    },
    description: 'A tropical paradise perched on a cliff edge. Offers complete privacy, an infinity edge pool blending with the ocean, and lush tropical gardens.',
    category: 'Villa',
    status: 'For Sale',
    featured: false
  }
];

export const testimonials = [
  {
    id: 1,
    name: 'James Rothschild',
    role: 'Investment Banker',
    content: 'The level of service and discretion provided by Luxe Estates is unmatched. They found the perfect off-market property in Mayfair for my family.',
    image: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&q=80&w=400'
  },
  {
    id: 2,
    name: 'Victoria Chen',
    role: 'Tech Entrepreneur',
    content: 'From the initial viewing to the final closing, the experience was seamless. Their knowledge of the luxury market in Silicon Valley is extraordinary.',
    image: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&q=80&w=400'
  },
  {
    id: 3,
    name: 'Sheikh Al-Maktoum',
    role: 'Business Magnate',
    content: 'Luxe Estates understands the true meaning of luxury. Their portfolio in Dubai represents the absolute pinnacle of real estate.',
    image: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&q=80&w=400'
  },
  {
    id: 4,
    name: 'Elena Rostova',
    role: 'International Art Collector',
    content: 'Finding a home that could safely house my collection was paramount. The team at Luxe Estates exceeded all expectations with a stunning Parisian property.',
    image: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=400'
  },
  {
    id: 5,
    name: 'Marcus Sterling',
    role: 'Hedge Fund Manager',
    content: 'Time is my most valuable asset. Luxe Estates streamlined the entire acquisition process for my Manhattan penthouse. Utterly professional.',
    image: 'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?auto=format&fit=crop&q=80&w=400'
  },
  {
    id: 6,
    name: 'Isabella Rossi',
    role: 'Fashion Designer',
    content: 'I needed a property in Milan that reflected my brand\'s aesthetic. They didn\'t just find me a house; they found me a masterpiece.',
    image: 'https://images.unsplash.com/photo-1531746020798-e6953c6e8e04?auto=format&fit=crop&q=80&w=400'
  },
  {
    id: 7,
    name: 'David Kensington',
    role: 'CEO, Global Logistics',
    content: 'Their global reach is not just a marketing slogan. They seamlessly coordinated the sale of my London estate and the purchase of my new home in Monaco.',
    image: 'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?auto=format&fit=crop&q=80&w=400'
  },
  {
    id: 8,
    name: 'Sophia Laurent',
    role: 'Film Director',
    content: 'Privacy was my number one concern. Luxe Estates handled my Malibu purchase with absolute discretion. I couldn\'t be happier.',
    image: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&q=80&w=400'
  },
  {
    id: 9,
    name: 'Arthur Pendelton',
    role: 'Real Estate Developer',
    content: 'As someone in the industry, my standards are impossibly high. Luxe Estates is the only agency I trust with my personal portfolio.',
    image: 'https://images.unsplash.com/photo-1556157382-97eda2d62296?auto=format&fit=crop&q=80&w=400'
  },
  {
    id: 10,
    name: 'Mei Lin',
    role: 'Philanthropist',
    content: 'The concierge service post-purchase was a revelation. They helped staff and manage my new estate in the Hamptons flawlessly.',
    image: 'https://images.unsplash.com/photo-1580489944761-15a19d654956?auto=format&fit=crop&q=80&w=400'
  },
  {
    id: 11,
    name: 'Alexander Volkov',
    role: 'Tech Investor',
    content: 'A truly bespoke experience. Their market insights gave me the confidence to make a significant investment in the emerging Miami luxury market.',
    image: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?auto=format&fit=crop&q=80&w=400'
  }
];

export const agents = [
  {
    id: 1,
    name: 'Sarah Jenkins',
    role: 'Managing Partner, US',
    phone: '+1 (310) 555-0198',
    email: 'sarah@luxeestates.com',
    image: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&q=80&w=800',
    sales: '$1.2B+'
  },
  {
    id: 2,
    name: 'Omar Al-Fayed',
    role: 'Director, Middle East',
    phone: '+971 50 555 0192',
    email: 'omar@luxeestates.com',
    image: 'https://images.unsplash.com/photo-1560250097-0b93528c311a?auto=format&fit=crop&q=80&w=800',
    sales: '$850M+'
  },
  {
    id: 3,
    name: 'Eleanor Vance',
    role: 'Senior Partner, UK',
    phone: '+44 20 7946 0123',
    email: 'eleanor@luxeestates.com',
    image: 'https://images.unsplash.com/photo-1580489944761-15a19d654956?auto=format&fit=crop&q=80&w=800',
    sales: '$920M+'
  },
  {
    id: 4,
    name: 'Michael Chen',
    role: 'Head of Global Investments',
    phone: '+1 (212) 555-0891',
    email: 'michael@luxeestates.com',
    image: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?auto=format&fit=crop&q=80&w=800',
    sales: '$1.5B+'
  }
];
