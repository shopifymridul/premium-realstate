import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL || 'https://nhkzzupubxjdtnaggivo.supabase.co';
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY || 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im5oa3p6dXB1YnhqZHRuYWdnaXZvIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzMyNDE5MDksImV4cCI6MjA4ODgxNzkwOX0.etDhglqBGh72RI0KFFeQCkB0VXZhAlddl-0YnOen3HA';

export const supabase = createClient(supabaseUrl, supabaseAnonKey);
